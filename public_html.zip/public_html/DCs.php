<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="Sugarland – Contemporary Portfolio for Creatives that Stands Out" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.php">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <!-- start main nav -->
	<?php include("nav.php"); ?>
    <!-- end main nav -->
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		  <h4 style="color:white">PHYMOL</h4>
		  <p>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
			<p><a href="research.php">&#x2190; Back to RESEARCH PROJECTS</a> </p>
			<div class="small-break"></div>
			<h4 class="content-title" id="title"></h4>
			<div class="small-break"></div>
			<p id="soa" style="text-align:justify;"> </p>
			<p id="rg" style="text-align:justify;"> </p>
			<p id="sec" style="text-align:justify;"> </p>
			<p id="dtd" style="text-align:justify;"> </p>
			<p id="pre" style="text-align:justify;"> </p>
			<p id="sb" style="text-align:justify;"> </p>
			<p id="lit" style="text-align:justify;"> </p>
			<p id="host" style="text-align:justify;"> </p>
			<p id="wp" style="text-align:justify;"> </p>
			<p id="sup" style="text-align:justify;"> </p>
			
			
        
      </div>
	  
	  
	  <!--
	   Right content
	  -->
        <?php include "right.php"; ?>
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 

<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 

<script>

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
    return false;
};


// Titles
var titles = [];
titles[0] = "";
titles[1] = "Towards the accurate description of the induction energy in Symmetry Adapted Perturbation Theory";
titles[2] = "Intermolecular interactions in excited states: the CO−CO∗ and other excimers";
titles[3] = "Collision-induced absorption and high-resolution spectra calculated from accurate <i>ab initio</i> potentials";
titles[4] = "Title: Reparametrisation of semiempirical models";
titles[5] = "Development of intermolecular force-fields with many-body dispersion interactions";
titles[6] = "Consistent treatment of polarization and charge-delocalization in many-body systems";
titles[7] = "How intermolecular interactions shape polymorphic energy landscapes";
titles[8] = "State-of-the art modelling of new quantum materials: surface-supported metal atomic quantum clusters";
titles[9] = "Implicit machine-learning solvent models for confined spaces";
titles[10] = "";
titles[11] = "Density-mapped force-fields: Rapid prototyping of intermolecular force-fields based on physical and machine-learned mappings onto properties of the electronic density";

// State-of-the-art
var soas = [];
soas[0] = "";
soas[1] = "<b>State-of-the-art:</b> Symmetry Adapted Perturbation Theory (SAPT) is one of the most powerful methods for calculations of the forces between molecules. Apart from excellent accuracy, the method provides us physical insight into the nature of molecular interaction and its deep understanding. Currently SAPT is being used for detailed studies of interactions: from small to very big molecular systems.";
soas[2] = "<b>State-of-the-art:</b> Excitation energy transfer between donor and acceptor chromophores can be computed by time dependent density functional theory (TDDFT) for relatively large molecules, such as light harvesting complexes. However, the results can depend strongly on the choice of the functional. For smaller systems, application of more accurate methods is also feasible.";
soas[3] = "<b>State-of-the-art:</b> Collision-induced absorption (CIA) is the absorption of light by colliding molecules. The contribution of CIA is typically weak and difficult to measure in laboratory experiments, but observable in atmospheric spectra. CIA is particularly important for the observation of exoplanetary atmospheres, and spectra for many relevant molecules are unknown.";
soas[4] = "<b>State-of-the-art:</b> The aim of the PhD project is to iteratively improve the accuracy of semiempirical methods, implemented within the MOPAC2016 program, for the evaluation of noncovalent interactions. This will be done using a database of reference DFT+D and coupled-cluster (CC) intermolecular interaction energies calculated for a set of specially chosen small molecules representing important functional groups. Corrections to the semiempirical models will be evaluated from this data set, and analytical correction functions will be obtained through fittings. Subsequent data sets containing larger molecules, with more complex functional units, will be added and the corresponding fits will be carriedout. After validation, the method will be applied to the study of other systems.";
soas[5] = "<b>State-of-the-art:</b> Although it has been shown to be important in many contexts, many-body dispersion effects are not taken into account within standard molecular mechanics force-fields, even most advanced ones, due to the associated large computational cost. Recently, algorithmic advances drastically reduced this complexity, allowing to develop efficient models including such interaction.";
soas[6] = "<b>State-of-the-art:</b> Modern models for the polarization are based on either point polarizabilities or on Drude oscillators. Both of these are able to capture the effects of local polarization, but it is not known if these models can be used to describe extended polarization (as seen in molecular conductors) and charge de- localization (as also seen when charge hops from one molecule to another or from one part of a system to another). Instead, a class of charge equilibration models have been proposed to deal with charge movement. Both kinds of models have undetermined parameters which are usually determined by fitting to induction energies computed using symmetry-adapted perturbation theory (specifically, a variant called SAPT(DFT)). These models have been shown to work very well for small molecular systems and have been used to predict the properties of molecular crystals, liquid water, water clusters, and also in larger bio-molecular simulations through semi-empirical parameterizations used in force-fields like AMOEBA.";
soas[7] = "<b>State-of-the-art:</b> Density functional theory (DFT) is the workhorse of modern computational chemistry due to its favorable balance of accuracy and speed. However, van der Waals interactions have proven to be challenging for DFT to calculate accurately. While for most small systems and properties of interest van der Waals forces are negligible, van der Waals forces become increasingly important for larger systems. In the case of molecular crystals, van der Waals interactions can be the dominant force holding the molecules together. This state of affairs has made the prediction of the lowest-energy, stable phase of molecular crystals quite challenging. This question is not only of academic interest, but of immense practical importance. Mass producing a pharmaceutical drug in a metastable crystal phase could lead to the drug becoming ineffective or, even worse, toxic as it slowly switches to the stable phase. <br/> Recently, we have shown that DFT can be supplemented with a model that approximates van der Waals interactions called the many-body dispersion (MBD) model and this can lead to quantitative accuracy in predicting molecular crystal structure. Armed with this new tool, we can finally begin to gain insight into how changing a molecule’s structure can change the balance between van der Waals and other intermolecular forces and influence the stability of different crystalline phases.";
soas[8] = "<b>State-of-the-art:</b> State-of-the-art modelling of the interaction of metal atomic quantum clusters AQCs (in either air, solution, or helium droplets) with the surface of technologically relevant materials, making the emphasis on the new optical and (photo-)catalytic properties acquired by the support as well as the the stability of the supported AQCs at high temperatures and oxygen pressures. A critical task is the development of accurate interaction models, particularly of the dispersion interaction, which are capable to characterising the interaction of the confined object (AQCs) by the confining environments, and also account for excitations. The proposed study is expected to provide basic, mechanistic information, and key simplifications that can be transferred to the reactions of industrial applications with the help of machine learning technologies.";
soas[9] = "<b>State-of-the-art:</b> Organic Crystal Structure Prediction (CSP) has recently made a big step forward with the ability to predict the relative stability of anhydrates and stoichiometric hydrates on a common free energy scale as a function of temperature and relative humidity, using a blend of various ab initio methods and tailor-made force fields as implemented in the GRACE software package and the FHI-aims code. Prediction services are routinely offered to pharmaceutical companies to assist with the selection of solid-state forms for drug formulation. <br/> More accurate tailor-made force fields are under development that combine electrostatic multipoles, charge penetration, atomic polarizabilities, anisotropic van der Waals interactions, anharmonic bend stretch and angle bend terms as well as intramolecular coupling terms to almost reach ab initio accuracy.";
soas[10] = "<b>State-of-the-art:</b>";
soas[11] = "<b>State-of-the-art:</b> Force-fields are convenient mathematical models that are used to describe the potential energy surface of interacting molecules. Models are usually proposed with a number of unknown parameters, and these are obtained by fitting to either experimental or theoretical data, or both. Of these models, some are meant to be general, while others are constructed for specific kinds of systems. It’s the latter that are almost always higher in accuracy. However the specifically made models take time and considerable computational resource to develop. Recent developments have made the job easier using novel sampling methods, information theoretic approaches to describing molecular properties in distributed form, Bayesian techniques, and various flavours of machine learning, but these methods are still demanding. What is missing is a mid-way approach: one that relies on key quantities that are easily computable, but which results in an interaction model of sufficiently high accuracy. Also, we need to be able to have the model correctly adapt when molecular conformations change, while continuing to remain computationally efficient to be used in simulations in major molecular dynamics programs.";

// Research goal
var rgs = [];
rgs[0] = "";
rgs[1] = "<b>Research goals:</b> The method works poorly for systems which are easily polarizable: metals, π-conjugated systems, molecules in excited states, radicals. This is due to the fact that the induction energy in such systems is not reproduced accurately enough. We will investigate new theories which will allow to use SAPT for much broader class of systems.";
rgs[2] = "<b>Research goals:</b> In this project, you will benchmark theoretical methods for the interactions between CO−CO∗ excimer states associated with the CO(A ← X) electronic transition. This system can be studied in full dimensionality, and comparison to experiment will provide a benchmark for theoretical methods.";
rgs[3] = "<b>Research goals:</b> In this project, you will compute molecular CIA spectra. This involves calculating ab initio interaction potentials, interaction-induced dipole-moment functions, as well as coupled-channels technique for molecular collisions. You will also benchmark interaction potentials against high-resolution spectroscopy, treated within the theory of spectroscopic networks.";
rgs[4] = "<b>Research goals:</b> 1) Selection of the reference molecules and interaction orientations. 2) Computation of DFT and CC intermolecular potential energies. 3) Evaluation of corrections to the selected semiempirical Hamiltonian (fit functions). 5) Evaluation of DFT interaction energies for larger systems. 6) Validation of the method. 7) Applications.";
rgs[5] = "<b>Research goals:</b><br/> – Develop the coupling between the AMOEBA & SIBFA polarizable force fields with MBD.<br/> – Assess models for deriving permanent and induced (static and fluctuating) moments and establish connections between them.<br/> – Evaluate performance on small molecules, supramolecular and biological systems, and molecular crystals.<br/> – Consider the transferability across chemical space of organic molecules using ML techniques in collaboration with Tkatchenko. <br/>";
rgs[6] = "<b>Research goals:</b> At present the models are incomplete: first of all the two physical effects — local polarization and charge delocalization — are almost always treated separately, second, there isn’t a clear theoretical framework for treating these effects when they occur within a molecule as it happens in large delocalised systems (e.g., carbon nanotubes), or in large flexible molecules such as proteins, and third, there is as yet no convincing way of determining the parameters of these models from a unified theoretical framework. In this project we seek to develop a framework to solve these problems. We will do this in stages that include: 1) Development of reference models using existing methods, 2) establishing the state-of-the-art by systematically comparing reference models against polarizable force fields like AMOEBA, 3) developing a theoretical framework for the polarization and charge delocalization and implementing it in code, and implementing the models in Tinker-HP, a molecular dynamics code that will be used as the vehicle for validation of the models.";
rgs[7] = "<b>Research goals:</b> The PhD candidate will construct a systematic set of molecules, from small to large and with varying functional groups, and calcu- late their polymorphic energy landscapes using the DFT+MBD method. This will lead to both fundamental understanding of structure-property relations in molecular crystals and provide useful guidance for pharmaceutical development.";
rgs[8] = "<b>Research goals:</b> 1) Development of a computational ab initio-routed model aimed to predict the AQCs stability at different environmental conditions as well as the UV-Vis spectra of surface-supported AQCs. 2) The design of highly stable surface-supported AQCs photo(catalysts).";
rgs[9] = "<b>Research goals:</b> The PhD candidate will first identify and implement a method to calculate the solvent free energy in non-stoichiometric pocket and channel hydrates by atomistic simulations using the next generation of tailor-made force fields. The accuracy of the approach will be assessed against experimental data.<br/> In a second step, the candidate will use the method to calculated hundreds of free energy values for various pocket and channel hydrates and try to establish a structure-based machine learning model for the economical prediction of the free energy of water in pockets and channels. <br/> If successful, the project will not only extend routine crystal structure prediction to two important classes of pharmaceutical hydrates, but also open the door to the prediction of organometallic framework structures in the presence of solvent.";
rgs[10] = "<b>Research goals:</b> ";
rgs[11] = "<b>Research goals:</b> The approach we will adopt to fulfil these goals is one that has been investigated by us and is based on mapping the parameters that appear in physical interaction models onto properties of the molecular densities. As the densities contain information specific to the molecules of interest, and as can be easily computed, or even learned by ML algorithms, this approach will lead to a rapid way of developing accurate models for specific systems, in the comformations of interest. This project will be developed in stages that include: 1) a critical survey of existing frameworks for mapping molecular and atoms-in-a-molecule (AIM) properties onto parameters in force-fields, 2) the development of accurate models for first- and second-order properties based on the density, 3) development of systematic approaches (in collaboration with DC6) for modelling the charge-delocalisation energy, 4) implementation of all methods into an open-source Python code, and 5) interfacing this code with Tinker-HP to be able to conduct proof-of-principle simulations that validate/test the approach. We will make use of ML techniques in this project as they will be particularly helpful in performing the mappings needed to determine the model parameters.";

//Secondments
var secs = [];
secs[0] = "";
secs[1] = "<b>Secondments:</b> Auburn University (the group of Prof. Konrad Patkowski), MolSSI, Queen Mary University in London";
secs[2] = "<b>Secondments:</b> Nijmegen (the group of Prof. Gerrit Groenenboom), HITRAN group at Harvard-Smithsonian Center for Astrophysics (Dr. Iouli Gordon)";
secs[3] = "<b>Secondments:</b> Torun (PL) (the group of Piotr Zuchowski), HITRAN group at Harvard-Smithsonian Center for Astrophysics (Iouli Gordon).";
secs[4] = "<b>Secondments:</b> The Doctoral Candidate will fully join the work and everyday life at the Computational and Theoretical Chemistry group in the Physical Chemistry Department of the University of Santiago de Compostela, participating in all the scientific events, conferences and seminars that periodically are organized. Three secondments are planned during the PhD: 4 months at the University of Luxemburg during the first year, in order to learn machine learning in the field of intermolecular potentials, a 2 month secondment at CSIC in Madrid to apply the learned methodology to the study of larger systems and systems under confinement and a last period of three months in CESGA during the second year to learn how to optimize the use of the programs and code needed in HPC machines. To carry out the work plan the computer facilities available at the Supercomputing Center of Galicia (CESGA: https://cesga.es/en/cesga) will be used.";
secs[5] = "<b>Secondments:</b> -";
secs[6] = "<b>Secondments:</b>  considerable amount of time will be spent in the group of Dr Alston J. Misquitta at Queen Mary University in London where much of the theoretical work will be performed.";
secs[7] = "";
secs[8] = "<b>Secondments:</b> UMK (Y1:4 months): training in ab initio methods such as SAPT(DFT) to compute accurate intermolecular interactions. NANOGAP(Y3:1mo): Learn about synthesis and nanomaterial characterization in an industrial environment. Work on AQC production and applications. Basic formation in in-dustrial manufacturing. KIDO(Y1:2mo): Learn efficient and scalable numerical algorithms in machine-learning techniques for the generation of pair-wise potential models.";
secs[9] = "";
secs[10] = "";
secs[11] = "<b>Secondments:</b> Prof Alexandre Tkatchenko at the University of Luxembourg (fundamentals of ML in relation to FFs) and Prof Jean-Philip Piquemal and Dr Louis Lagardere at Sorbonne University (use of models in simulations usingTinker-HP).";

//Day-to-day
var dtds = [];
dtds[0] = "";
dtds[1] = "<b>Day-to-day:</b> The research involve derivation of formulas in many-electron theories (with the help of symbolic algebra programs), prototype programming in python-based Psi4 quantum chemistry code, possibly efficient implementation in low-level programming languages (Fortran, C++).";
dtds[2] = "<b>Day-to-day:</b> The research involves computational work using existing computer codes (for symmetry-adapted perturbation theory (SAPT) and vibrational spectra) as well as method development (extension of SAPT to open-shell systems, diabatization to go beyond the Born-Oppenheimer approximation). This includes programming in languages such as Fortran, C++, Scilab, or Python.";
dtds[3] = "<b>Day-to-day:</b> The research involves computational work using existing computer codes (for ab initio calculations, collision dynamics, and spectra) as well as significant method development. This includes programming (in languages such as Fortran, C++, scilab, or Python).";
dtds[4] = "<b>Day-to-day:</b> The research plan will start with a search through the bibliography on previous work related to the project, and the study of the relevant references found. As starting point the doctoral candidate will consider the work already carried out by our research group on the subject. The second part of the research involves computational work using code already available and method development within the MOPAC2016 and xTB programs. This includes programming in Fortran and/or Python. In the last half of the PhD additional emphasis will be placed on the presentation (communication and dissemination) of the obtained results.";
dtds[5] = "<b>Day-to-day:</b> The research involves computational work using existing computer codes as well as significant method development. This includes programming in languages such as Fortran and Python.";
dtds[6] = "<b>Day-to-day:</b> The research will involve a near equal mix of theory, computation and code development. Reference models will need to be created using existing methods; some of these will need to be implemented in efficient code (Python, C++ or Fortran90), and new theoretical models will need to be developed. You will work in a Linux/Unix environment and will use high-performance computing (HPC) machines in simulations using Tinker-HP and intermolecular interaction calculations using Psi4, SAPT2020, CamCASP and other codes.";
dtds[7] = "<b>Day-to-day:</b> The research will involve mastering the use of a DFT software package to perform accurate calculations efficiently on a Linux-based high performance computing cluster. Additionally, the doctoral candidate will use python, or some other programming language, to automate DFT calculations and the extraction of various molecular properties from these calculations for a large set of materials. The doctoral candidate will need to gain proficiency in the literature of molecular crystals, especially those of pharmaceutical relevance, and use that knowledge to select a representative set of molecules which have reliable experimental data, are computationally feasible, and can tease out the relevant physics governing the stability of molecular crystalline phases. It will probably also be necessary to dive into the long-standing open problem of the prediction of plausible molecular crystal structures to fill in structures that are missing from the data set. State-of-the-art methods will be needed, possibly requiring a lightweight in-house implementation in python. Above all, attention to detail will be of the highest importance for this work, as there are many numerical challenges for large DFT calculations and many intricacies in how molecular crystals pack into different symmetries. The TCP group has several experienced postdocs that will be able to assist the doctoral candidate in mastering the vari- ous aspects of this research. Additionally, this work will be co-supervised by our industrial partner in order to direct the research towards real world applications.";
dtds[8] = "<b>Day-to-day:</b> Dealing with quantum chemistry calculations, molecular dynamics simulations and machine learning algorithms to investigate most the special properties of the smallest metal clusters as well as their integration into materials interacting with the environment to boost their performance in applications (e.g., energy conversion and photocatalysis). Numerical (quantum and classical) simulations of helium droplet-mediated surface deposition processes are also included.";
dtds[9] = "<b>Day-to-day:</b> The candidate will search the scientific literature for molecular simulation methods to compute the solvent free energy in framework structures and to predict properties of such structures by machine learning. Using Python and C++, he/she will implement such a method in GRACE or interface existing third-party code for free energy calculations (potentially written in Fortran) with the tailor-made force fields available in GRACE. Software development tasks also include the implementation of a high-throughput workflow for the computation of hundreds of free energies, the development of software for the training of a machine learning model to predict solvent free energies and the combination of such a machine learning model with the force-field based energy calculations in GRACE. Calculations will be run on one of AMS’ high-throughput in-house LINUX clusters featuring several thousands of cores. The candidate will collect experimental information from the scientific literature and pharmaceutical companies willing to make contributions. He/she will meet several timers per week with his/her supervisor at AMS to decide on short-term priorities and once per month with the software development and contract research teams to brainstorm about problem solution strategies and to identify permanent staff members best suited to train the candidate on the required skills.";
dtds[10] = "<b>Day-to-day:</b> ";
dtds[11] = "<b>Day-to-day:</b> The research will involve a near equal mix of theory, computation and code development. Reference models will need to be created using existing methods; some of these will need to be implemented in efficient code (Python, C++ or Fortran90), and new theoretical models will need to be developed. You will work in a Linux/Unix environment and will use high-performance computing (HPC) machines in simulations using Tinker-HP and intermolecular interaction calculations using Psi4, CamCASP and other codes.";

//Pre-requisites
var pres = [];
pres[0] = "";
pres[1] = "<b>Pre-requisites:</b> Knowledge of many-body quantum mechanics, quantum chemistry, good programming skills in Python. Knowledge of linux, HPC skills (queuing systems, script languages) are welcome. Master degree in physics, chemistry or related disciplines is required.";
pres[2] = "<b>Pre-requisites:</b> Good knowledge of quantum chemistry and affinity for molecular physics is required, as is a M.Sc. in physics, chemistry, or a related discipline. Programming experience is welcomed.";
pres[3] = "<b>Pre-requisites:</b> Good knowledge of quantum mechanics and affinity for molecular physics is required, as is a M.Sc. in physics, chemistry, or a related discipline. Programming experience is welcomed.";
pres[4] = "<b>Pre-requisites:</b> We are looking for an outstanding and highly motivated candidate with excellent grades in the Bachelor and Master education and a solid background in quantum chemistry, molecular physics and python and fortran programming. Knowledge of Linux and written and spoken English is also required.";
pres[5] = "<b>Pre-requisites:</b> Knowledge of many-body quantum mechanics, quantum chemistry, good programming skills as well as working knowledge of Linux, HPC skills. A master’s degree in physics, chemistry or related disciplines is required.";
pres[6] = "<b>Pre-requisites:</b> Knowledge of many-body quantum mechanics, quantum chemistry, good programming skills in Python. Also welcome but not essential: working knowledge of Linux, HPC skills (queuing systems, script languages). A master’s degree in physics, chemistry or related disciplines is required.";
pres[7] = "<b>Pre-requisites:</b> Good mathematical and programming skills, a good understanding of basic quantum mechanics, and physical and chemical intuition.";
pres[8] = "<b>Pre-requisites:</b> The candidate should have a strong background in quantum chemistry, molecular physics and python programming. Relevant areas of expertise might include application of machine learning methods to materials or molecular dynamics to intermolecular interactions.";
pres[9] = "<b>Pre-requisites:</b> Good mathematical and programming skills, a good understanding of statistical thermodynamics, and physical and chemical intuition.";
pres[10] = "<b>Pre-requisites:</b> ";
pres[11] = "<b>Pre-requisites:</b> Desirable: Knowledge of many-body quantum mechanics, quantum chemistry, good programming skills in Python. Also welcome but not essential: working knowledge of Linux, HPC skills (queuing systems, script languages). A master’s degree in physics, chemistry or related disciplines is required.";

//Stipend and benefits
var sbs = [];
sbs[0] = "";
sbs[1] = "<b>Stipend and benefits:</b> Around 1800 Euro monthly net salary.";
sbs[2] = ""; //<b>Stipend and benefits:</b> The position is for 4 years. Salary, benefits, holidays etc. follow the  <a href='https://www.universiteitenvannederland.nl/en_GB/cao-universiteiten.html' target='_blank'> collective labor agreement for Dutch Universities</a>
sbs[3] = "";
sbs[4] = "<b>Stipend and benefits:</b> The period of the contract is for three years. The salary will follow the EU MSCA rules and will include living, mobility and family allowances. The latest starting date is the 1st September 2023.";
sbs[5] = "";
sbs[6] = "";
sbs[7] = "<b>Stipend and benefits:</b> The yearly gross salary for every PhD at the University of Luxembourg is EUR 38.028,96 (full time)";
sbs[8] = "<b>Stipend and benefits:</b> The yearly gross salary for every PhD at the Spanish National Research Council is about EUR 43.000 (full time).";
sbs[9] = "";
sbs[10] = "";
sbs[11] = "";

// Literature References
var lit=[];
lit[0]="";
lit[1]="";
lit[2]="";
lit[3]="<b>Literature References:</b> [1] 'O2-O2 and O2-N2 collision-induced absorption mechanisms unravelled ', Tijs Karman, Mark A. J. Koenis, Agniva Banerjee, David H. Parker, Iouli E. Gordon, Ad van der Avoird, Wim J. van der Zande, and Gerrit C. Groenenboom, Nature Chem., 10, 549 (2018).";
lit[4]="<b>Literature References:</b> 1. S. Pérez-Tabero, B. Fernández, E. M. Cabaleiro-Lago, E. Martínez-Núñez and S. A. Vázquez, New Approach for Correcting Noncovalent Interactions in Semiempirical Quantum Mechanical Methods: The Importance of Multiple- Orientation Sampling, J. Chem. Theor. Comput., 17, 556-5567 (2021), https://doi.org/10.1021/acs.jctc.1c00365. <br/> Here a new approach is presented to improve the performance of semiempirical quantum mechanical (SQM) methods in the description of noncovalent interactions. To show the strategy, the PM6 Hamiltonian was selected, although, in general, the procedure can be applied to other semiempirical Hamiltonians and to different methodologies. A set of small molecules were selected as representative of various functional groups, and intermolecular potential energy curves (IPECs) were evaluated for the most relevant orientations of interacting molecular pairs. Then, analytical corrections to PM6 were derived from fits to B3LYP-D3/def2-TZVP reference–PM6 interaction energy differences. IPECs provided by the B3LYP-D3/def2-TZVP combination of the electronic structure method and basis set were chosen as the reference because they are in excellent agreement with CCSD(T)/aug-cc-pVTZ curves for the studied systems. The resulting method, called PM6-FGC (from functional group corrections), significantly improves the performance of PM6 and shows the importance of including a sufficient number of orientations of the interacting molecules in the reference data set in order to obtain well-balanced descriptions. <br/><br/> 2. M. Rios-García, B. Fernández, J. Rodríguez-Otero, E. M. Cabaleiro-Lago and S. A. Vázquez, The PM6-FGC Method: Improved Corrections for Amines and Amides, Molecules, 27, 1678 (2022), https://doi.org/10.3390/molecules27051678. <br/> Here we improved the PM6-FGC method in the description of some interactions involving the –NH2 group in amines and amides. In this way, methylamine and acetamide are used as representatives of amine and amide groups, respectively. This new selection leads to significant improvements in the calculation of non-covalent interactions in the validation set.";
lit[5] ="<b>Literature References:</b> Accurate and Efficient Method for Many-Body van der Waals Interactions,Alexandre Tkatchenko, Robert A. DiStasio, Jr., Roberto Car, and Matthias Scheffler, Phys. Rev. Lett. 108, 236402,<br/> Tinker-HP: a massively parallel molecular dynamics package for multiscale simulations of large complex systems with advanced point dipole polarizable force fields L Lagard`ere et al. Chemical science 9 (4), 956-972,<br/> O(N) Stochastic Evaluation of Many-Body van der Waals Energies in Large Complex Systems PP Poier, L Lagard`ere, JP Piquemal Journal of Chemical Theory and Computation 18 (3), 1633-164";
lit[6]="<b>Literature References:</b> [1] “First-Principles Many-Body Nonadditive Polarization Energies from Monomer and Dimer Calculations Only: A Case Study on Water”, Rory AJ Gilmore, Martin T Dove, Alston J Misquitta, Journal of chemical theory and computation 16, 224–242 (2020). [2] “From dimers to the solid-state: Distributed intermolecular force-fields for pyridine”, Alexander A Aina, Alston J Misquitta, Sarah L Price, J. Chem. Phys., 147, 161722 (2017). [3] “Distributed multipoles from a robust basis-space implementation of the iterated stockholder atoms procedure”, A. J. Misquitta, A. J. Stone and F. Fazeli, J. Chem. Theor. Comput., 10, 5405–5418 (2014). [4] “Describing Molecular Polarizability by a Bond Capacity Model”, P. P. Poier and F. Jensen, J. Chem. Theory Comput. 2019, 15, 5, 3093–3107.";
lit[7] = "<b>Literature References:</b> [1] Johannes Hoja and Hsin-Yu Ko and Marcus A. Neumann and Roberto Car and Robert A. DiStasio and Alexandre Tkatchenko ”Reliable and practical computational description of molecular crystal polymorphs” Sci. Adv.,5, eaau3338 (2019) https://www.science.org/doi/abs/10.1126/sciadv.aau3338 provides an excellent overview of the general problem and the method, DFT+MBD, that the doctoral candidate will use.";
lit[8] = "<b>Literature References:</b> As a recent review see: de Lara-Castells, First-principles modelling of the new generation of subnanometric metal clusters: Recent case studies, Journal of Colloid and Interface Science 612: 737–759 (2022).";
lit[9]="<b>Literature References:</b> CSP for hydrates and anhydrates: to be submitted. As an example for pharmaceutical CSP see Mortazavi M. et al., Computational Polymorph Screening Reveals Late-Appearing and Poorly-Soluble Form of Rotigotine, Commun Chem 2: 70 (2019).";
lit[10]="";
lit[11] = "<b>Literature References:</b> [1] “First-Principles Many-Body Nonadditive Polarization Energies from Monomer and Dimer Calculations Only: A Case Study on Water”, Rory AJ Gilmore, Martin T Dove, Alston J Misquitta, Journal of chemical theory and computation 16, 224–242 (2020). [2] “From dimers to the solid-state: Distributed intermolecular force-fields for pyridine”, Alexander A Aina, Alston J Misquitta, Sarah L Price, J. Chem. Phys., 147, 161722 (2017). [3] “Distributed multipoles from a robust basis-space implementation of the iterated stockholder atoms procedure”, A. J. Misquitta, A. J. Stone and F. Fazeli, J. Chem. Theor. Comput., 10, 5405–5418 (2014). [4] “Beyond Born–Mayer: Improved models for short-range repulsion in ab initio force fields”, M. J. Van Vleet, A. J. Misquitta, A. J. Stone and J. R. Schmidt, J. Chem. Theor. Comput., 12, 3851–3870 (2016).";

//Host institution
var  host=[];
host[0] = "";
host[1] = "";
host[2] = "<b>Host institution:</b> MTA-ELTE Complex Chemical Systems Research Group at ELTE Eötvös Loránd University, Budapest, Hungary.";
host[3] = "<b>Host institution:</b> Radboud University Nijmegen (RUN)";
host[4] = "<b>Host institution:</b> University of Santiago de Compostela, Department of Physical Chemistry, Computational and Theoretical Chemistry group.<br/> The University of Santiago de Compostela (USC, http://www.usc.es) is a public university founded in 1495. It offers a total of 52 bachelor degrees, 55 doctoral programs, and 59 master degrees. More than 2,000 professionals work at USC (about 38% female) and around 26,000 students per year. In 2016, USC was ranked among the top ten Spanish universities.";
host[5] = "<b>Host institution:</b> This project will be hosted by Sorbonne University in close collaboration with the University of Luxembourg. Sorbonne University is ranked 2nd in research quality in France in the 2022 Shanghai ranking, possesses large HPC capabilities and is member of the MOSER CECAM (Centre Europ´een de Calcul Atomique et Mol´eculaire) node (CECAM-FR-MOSER).";
host[6] = "<b>Host institution:</b> This project will be hosted by Sorbonne University in close collaboration with Queen Mary University of London (QMUL). Sorbonne University is ranked 2nd in research quality in France in the 2022 Shanghai ranking, possesses large HPC capabilities and is member of the MOSER CECAM (Centre Europ´een de Calcul Atomique et Mol´eculaire) node (CECAM-FR-MOSER). QMUL is a is a ‘Russell Group’ UK higher education institute conducting the very best research and outstanding teaching and learning. It is ranked 7th in research quality in the 2022 UK Research Excellence Framework (REF). Particularly relevant to PHYMOL is the Digital Environment Research Institute which brings together more than 150 research staff engaged with data science and machine learning across the disciplines. QMUL has access to a high-performance computing facility, Apocrita, a 350 node (12,500 cores) heterogeneous HPC cluster. Additionally, QMUL is part of the Thomas Young Centre for Theory and Simulation of Materials and Molecules which is a dynamic and interdisciplinary alliance of London researchers operating at the forefront of science.";
host[7]= "<b>Host institution:</b> University of Luxembourg ranks 25th in the 2022 Times Higher Education Young University Ranking and 3rd worldwide in International Outlook. Avant-garde Materials Simulation Deutschland GmbH, in Freiburg, Germany, is a subsidiary of AMS SARL, founded by Dr. Marcus Neumann in 2002. It is privately owned and was created with funding and strong support from a major pharmaceutical company. The company’s main goal is the development of software for crystal structure prediction (GRACE initiative).";
host[8] = "";
host[9]="<b>Host institution:</b> The family-owned high-tech business Avant-garde Materials Simulation Deutschland GmbH located in Freiburg, Germany, is the world-leader in organic crystal structure prediction. University of Luxembourg ranks 25th in the 2022 Times Higher Education Young University Ranking and 3rd worldwide in International Outlook.";
host[10] = "";
host[11] ="<b>Host institution:</b> This project will be hosted by Queen Mary University of London (QMUL). QMUL is a is a ‘Russell Group’ UK higher education institute conducting the very best research and outstanding teaching and learning. It is ranked 7th in research quality in the 2022 UK Research Excellence Framework (REF). Particularly relevant to PHYMOL is the Digital Environment Research Institute which brings together more than 150 research staff engaged with data science and machine learning across the disciplines. QMUL has access to a highperformance computing facility, Apocrita, a 350 node (12,500 cores) heterogeneous HPC cluster. Additionally, QMUL is part of the Thomas Young Centre for Theory and Simulation of Materials and Molecules which is a dynamic and interdisciplinary alliance of London researchers operating at the forefront of science.";


// Webpages
var wps = [];
wps[0] = "";
wps[1] = "<b>Webpage(s):</b> <a href='https://www.molintlab.com/' target='_blank'>Torun group website</a>";
wps[2] = "<b>Webpage(s):</b> <a href='http://csaszar.chem.elte.hu/' target='_blank'>Budapest group website</a>";
wps[3] = "<b>Webpage(s):</b> <a href='https://www.theochem.ru.nl/' target='_blank'>Nijmegen group website</a>";
wps[4] = "<b>Webpage(s):</b> <a href='https://computchem.gal/' target='_blank'>computchem.gal</a>";
wps[5] = "<b>Webpage(s):</b> <a href='https://piquemalresearch.com/ target='_blank'>Piquemal group</a>";
wps[6] = "<b>Webpage(s):</b> <a href='https://www.qmul.ac.uk/spcs/staff/academics/profiles/ajmisquitta.html' target='_blank'> Misquitta group website</a>, <a href='https://piquemalresearch.com/' target='_blank'>Piquemal group</a>";
wps[7] = "<b>Webpage(s):</b> <a href='https://www.tcpunilu.com/' target='_blank'> https://www.tcpunilu.com/</a>, <a href='https://www.avmatsim.eu' target='_blank'>https://www.avmatsim.eu</a>";
wps[8] = "<b>Webpage(s):</b> <a href='https://www.kidodynamics.com/' target='_blank'>www.kidodynamics.com</a>";
wps[9] = "<b>Webpage(s):</b> <a href='https://www.avmatsim.eu' target='_blank'>www.avmatsim.eu</a>, <a href='https://www.tcpunilu.com/' target='_blank'>www.tcpunilu.com</a>, <a href='https://www.qmul.ac.uk/spcs/staff/academics/profiles/ajmisquitta.html' target='_blank'>Misquitta group website</a>";
 wps[10] = "<b>Webpage(s):</b> ";
 wps[11] = "<b>Webpage(s):</b> <a href='https://www.qmul.ac.uk/spcs/staff/academics/profiles/ajmisquitta.html' target='_blank'>Misquitta group website</a>";

// supevisors

var sups = [];
sups[0] = "";
sups[1] = "";
sups[2] = "";
sups[3] = "";
sups[4] = "<b>Supervisors:</b> S. A. Vázquez, B. Fernández; (Co-supervisor A. Tkatchenko; Mentor: M. P. Lara-Castells) S. A. Váquez’s research has been devoted to understanding the dynamics of chemical reactions in gas phase as well as the dynamics of collisions of molecules with self-assembled monolayers and the development of automated methods for predicting reaction mechanisms and kinetics of complex reactions. B. Fernández has wide experience on the highly accurate evaluation of molecular and intramolecular properties using ab initio methods. In particular, she has been working on the accurate evaluation of intermolecular potentials and properties in van der Waals and H-bonded complexes. Recently, both collaborate in the development and improvement of intermolecular potentials for molecular-mechanics force fields and semiempirical Hamiltonians.";
sups[5] = "";
sups[6] = "";
sups[7] = "";
sups[8] = "";
sups[9] = "";
sups[10] = "";
sups[11] = "";

$( document ).ready(function() {
    var url_string = window.location.search;
	//var url = new URL(url_string);
    var dc = getUrlParameter("dc");
	
	$("#title").html("DC"+dc+": "+titles[dc]);
	$("#soa").html(soas[dc]);
	$("#rg").html(rgs[dc]);
	$("#sec").html(secs[dc]);
	$("#dtd").html(dtds[dc]);
	$("#pre").html(pres[dc]);
	$("#sb").html(sbs[dc]);
	$("#lit").html(lit[dc]);
	$("#host").html(host[dc]);
	$("#wp").html(wps[dc]);
	$("#sup").html(sups[dc]);
});


</script>


</body>
</html>