<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.php">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <!-- start main nav -->
    <?php include("nav.php"); ?>
    <!-- end main nav -->
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		  <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
	  
			<h4 class="content-title">MEMBERS</h4>
			<p class="gold"><strong>Universytet Mikołaja Kopernika</strong><p>
			<div  class="boxed autodiv" id="anna">
				<div class="avatar"><img alt="" src="pics/anna.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. Anna Kaczmarek-Kedziera</h4>
				
				<p class="pl170">
					<b>Country</b>: PL<br/>
					<b>Website</b>: <a href="https://orcid.org/0000-0002-4931-8701" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Faculty of Chemistry <br/>
				</p>
			 
			</div>
			
			<p class="gold"><strong>Queen Mary University of London</strong><p>
			<div  class="boxed autodiv" id="misquitta">
				<div class="avatar"><img alt="" src="pics/alston.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. Alston J. Misquitta</h4>
				
				<p class="pl170">
					<b>Country</b>: UK<br/>
					<b>Website</b>: <a href="https://www.qmul.ac.uk/spcs/staff/academics/profiles/ajmisquitta.html" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: School of Physical and Chemical Sciences<br/>
				</p>
			 
			</div>	
			<div class="small-break"></div>	 
			<p class="gold"><strong>University of London</strong><p>
			<div  class="boxed autodiv" id="otero">
				<div class="avatar"><img alt="" src="pics/Crespo.jpg"></div>
				
				<h4 class="bentitle pl170">University College London</h4>
				
				<p class="pl170">
					<b>Country</b>: UK<br/>
					<b>Website</b>: <a href="https://profiles.ucl.ac.uk/94278-rachel-crespo-otero/about" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Faculty of Chemistry <br/>
				</p>
			 
			</div>	
			<div class="small-break"></div>	 			
			<p class="gold"><strong>Universytet Mikołaja Kopernika</strong><p>
			
			<div  class="boxed autodiv" id="zuchowski">
				<div class="avatar"><img alt="" src="pics/PZuchowski.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. Piotr Zuchowski</h4>
				
				<p class="pl170">
					<b>Country</b>: PL<br/>
					<b>Website</b>: <a href="http://fizyka.umk.pl/~pzuch/index.html" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Faculty of Physics<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Universidad de Santiago de Compostela</strong><p>
			
			<div  class="boxed autodiv" id="BertaFR">
				<div class="avatar"><img alt="" src="pics/bertafernandez_0.jpg"></div>
				
				<h4 class="bentitle pl170">Prof. Berta Fernández Rodríguez</h4>
				
				<p class="pl170">
					<b>Country</b>: ES<br/>
					<b>Website</b>: <a href="https://investigacion.usc.gal/investigadores/58934/detalle?lang=en" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Department of Physical Chemistry<br/>
				</p>
			 
			</div>	
			<div class="small-break"></div>	
			<div  class="boxed autodiv" id="SauloVR">
				<div class="avatar"><img alt="" src="pics/saulo_s2.jpg"></div>
				
				<h4 class="bentitle pl170">Prof. Saulo A. Vázquez Rodríguez</h4>
				
				<p class="pl170">
					<b>Country</b>: ES<br/>
					<b>Website</b>: <a href="https://investigacion.usc.gal/investigadores/60577/detalle?lang=en" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Department of Physical Chemistry<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Université du Luxembourg</strong><p>
			
			<div  class="boxed autodiv" id="Tkatchenko">
				<div class="avatar"><img alt="" src="pics/alexTkatchenko.webp"></div>
				
				<h4 class="bentitle pl170">Prof. Alexandre Tkatchenko</h4>
				
				<p class="pl170">
					<b>Country</b>: LU<br/>
					<b>Website</b>: <a href="https://wwwfr.uni.lu/recherche/fstm/dphyms/people/alexandre_tkatchenko" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Physics and Materials Science<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Radboud University Nijmegen</strong><p>
			
			<div  class="boxed autodiv" id="Karman">
				<div class="avatar"><img alt="" src="pics/tijsKarman.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. Tijs Karman</h4>
				
				<p class="pl170">
					<b>Country</b>: NL<br/>
					<b>Website</b>: <a href="https://www.theochem.ru.nl/~tkarman/" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Theoretical Chemistry<br/>
				</p>
			 
			</div>

			<div class="small-break"></div>	   
			
			<div  class="boxed autodiv" id="Groenenboom">
				<div class="avatar"><img alt="" src="pics/gcg-may-2013.jpg"></div>
				
				<h4 class="bentitle pl170">Prof. Gerrit C. Groenenboom</h4>
				
				<p class="pl170">
					<b>Country</b>: NL<br/>
					<b>Website</b>: <a href="https://www.theochem.ru.nl/~gerritg/" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Theoretical Chemistry<br/>
				</p>
			 
			</div>	

			<div class="small-break"></div>	   
			
			<div  class="boxed autodiv" id="Avoird">
				<div class="avatar"><img alt="" src="pics/ad1.jpg"></div>
				
				<h4 class="bentitle pl170">Prof. Ad van der Avoird</h4>
				
				<p class="pl170">
					<b>Country</b>: NL<br/>
					<b>Website</b>: <a href="https://www.theochem.ru.nl/~avda/" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Theoretical Chemistry<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Consejo Superior de Investigaciones Cientificas</strong><p>
			
			<div  class="boxed autodiv" id="Castells">
				<div class="avatar"><img alt="" src="pics/MPilar.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. M. Pilar de Lara-Castells</h4>
				
				<p class="pl170">
					<b>Country</b>: ES<br/>
					<b>Website</b>: <a href="http://www.abinitsim.iff.csic.es/mariapilardelaracastells" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Research<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Sorbonne Université</strong><p>
			
			<div  class="boxed autodiv" id="Piquemal">
				<div class="avatar"><img alt="" src="pics/Jean-Philip-Piquemal.jpg"></div>
				
				<h4 class="bentitle pl170">Prof. Jean-P. Piquemal</h4>
				
				<p class="pl170">
					<b>Country</b>: FR<br/>
					<b>Website</b>: <a href="https://piquemalresearch.com/" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Laboratoire de Chimie Théorique<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<div  class="boxed autodiv" id="Lagardere">
				<div class="avatar"><img alt="" src="pics/Lagardere.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. Louis Lagardere</h4>
				
				<p class="pl170">
					<b>Country</b>: FR<br/>
					<b>Website</b>: <a href="https://scholar.google.fr/citations?user=Iuujj6sAAAAJ&hl=fr" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Laboratoire de Chimie Théorique<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Eötvös Loránd University</strong><p>
			
			<div  class="boxed autodiv" id="AGC">
				<div class="avatar"><img alt="" src="pics/ACS.jpg"></div>
				
				<h4 class="bentitle pl170">Prof. Attila G. Császár</h4>
				
				<p class="pl170">
					<b>Country</b>: HU<br/>
					<b>Website</b>: <a href="http://csaszar.chem.elte.hu/" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Institute of Chemistry<br/>
				</p>
			 
			</div>	
			
			<div class="small-break"></div>	   
			<p class="gold"><strong>Avant-garde Materials Simulations</strong><p>
			
			<div  class="boxed autodiv" id="Neumann">
				<div class="avatar"><img alt="" src="pics/MNeumann.jpg"></div>
				
				<h4 class="bentitle pl170">Dr. Marcus Neumann</h4>
				
				<p class="pl170">
					<b>Country</b>: DE<br/>
					<b>Website</b>: <a href="https://www.researchgate.net/profile/Marcus-Neumann-2" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: -<br/>
				</p>
			 
			</div>	
			<!---
			<div class="small-break"></div>	   
			<p class="gold"><strong>KIDO Dynamics SA</strong><p>
			
			<div  class="boxed autodiv" id="Hernando">
				<div class="avatar"><img alt="" src="pics/AHernando.webp"></div>
				
				<h4 class="bentitle pl170">Dr. Alberto Hernando</h4>
				
				<p class="pl170">
					<b>Country</b>: ES<br/>
					<b>Website</b>: <a href="https://www.researchgate.net/profile/Alberto-Hernando-De-Castro" target="_blank">Link</a><br/>
					<b>Department Division Laboratory</b>: Research<br/>
				</p>
			 
			</div>	
			--->
        
      </div>
	  
	  
	   <!--
	   Right content
	  -->
      <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 


<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 



</body>
</html>