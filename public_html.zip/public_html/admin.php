<?php

include("include/classes/session.php");

function redirect($url)
{
	if (headers_sent()){
	  die('<script type="text/javascript">window.location.href="' . $url . '";</script>');
	}else{
	  header('Location: ' . $url);
	  die();
	}    
}

if ((!$session->logged_in)) {
	if(!$session->isLevel9()){
		redirect("index.php");
	}
}



?>
<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="Sugarland – Contemporary Portfolio for Creatives that Stands Out" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script> 	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.html">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
   <?php include("nav.php"); ?>
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		 <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
			<h4>ADMIN</h4>
			
			<div class="col-md-6">
				<div class=" centered">
					<a href="doit.php?page=1" class="btn btn-outline-info btn-lg" role="button">New News</a>
				</div>
			 </div>
			 
			 <div class="col-md-6">
				<div class=" centered">
					<a href="doit.php?page=2" class="btn btn-outline-info btn-lg" role="button">Edit News</a>
				</div>
			 </div>
			 <div class="clear"></div><br/>
			 <p><a href="news.php">See all news</a></p>
			 <hr/>
			 
			 <div class="small-break"></div>
			  <div class="col-md-6">
				<div class=" centered">
					<a href="doit.php?page=5" class="btn btn-outline-info btn-lg" role="button">New Events</a>
				</div>
			 </div>
			 
			  <div class="col-md-6">
				<div class=" centered">
					<a href="doit.php?page=6" class="btn btn-outline-info btn-lg" role="button">Edit Events</a>
				</div>
			 </div>
			 
        
      </div>
	  
	  
	   <!--
	   Right content
	  -->
      <div class="col-md-3 col-sm-8 ">
        <div class="small-break"></div>
        <div class="boxed keys">
          <p><strong>Key Facts</strong></p>
         
          <ul class="clearfix keysul">
              <li> Scientific beneficiaries: 10 </li>
            <li> Partners: 6 </li>
            <li> Number of countries involved: 10 </li>
            <li> Budget: approx. €2.6M from Horizon Europe and €300K from UKRI. </li>
            <li> Number of funded doctoral candidates: 11 </li>
            <li> Coordinated by Prof Piotr Zuchowski from Universytet Mikłaja Kopernika, Torun </li>
            <li> PHYMOL is a doctoral network funded mainly under the Horizon Europe scheme, and also by the UK Research and Innovation</li>
          </ul>
        </div>
		
		<div  style="width:100%;">
		<a title="ITN - Marie Curie Actions" href="https://marie-sklodowska-curie-actions.ec.europa.eu/" target="_blank"><img style="max-width:150px;" class="cimage" src="pics/EC.png"></a>
		 
		 </div>
		  <div class="small-break"></div>
		 <div  class="homecontact" >
		   <p class="gold"><strong>Contact</strong></p>
		   <p class="gold">Coordinator:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:pzuch@fizyka.umk.pl"  class="gold">Piotr Zuchowski</a></p>
		    <p class="gold">Project Manager:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:a_wis@umk.pl"  class="gold">Agata Wiśniewska </a></p>
		 
		 </div>
		 <div class="small-break"></div>
		 <div  style="width:100%; padding-left:10px">
		   <p class="gold">Also find us on :</p>
		   
		   <ul class="social-list clearfix">
			
			<li> <a href="https://www.linkedin.com/company/85627029/admin/" target="_blank" class="circled"><i class="fa fa-linkedin"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
			<li> <a href="#" class="circled"><i class="fa fa-twitter"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
		  </ul>
	  
		 </div>
		 
      </div>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 



<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 




</body>
</html>