 <!--
	   Right content
	  -->
      <div class="col-md-3 col-sm-8 ">
        <div class="small-break"></div>
        <div class="boxed keys">
          <p><strong>Key Facts</strong></p>
         
          <ul class="clearfix keysul">
              <li> Scientific beneficiaries: 10 </li>
            <li> Partners: 6 </li>
            <li> Number of countries involved: 10 </li>
            <li> Budget: approx. €2.6M from Horizon Europe and €300K from UKRI. </li>
            <li> Number of funded doctoral candidates: 11 </li>
            <li> Coordinated by Prof Piotr Zuchowski from Universytet Mikłaja Kopernika, Torun </li>
            <li> PHYMOL is a doctoral network funded mainly under the Horizon Europe scheme, and also by the UK Research and Innovation</li>
          </ul>
        </div>
		
		<div  style="width:100%;">
		<a title="ITN - Marie Curie Actions" href="https://marie-sklodowska-curie-actions.ec.europa.eu/" target="_blank"><img style="max-width:150px;" class="cimage" src="pics/EC.png"></a>
		 </div>
		 <div class="small-break"></div>
		 <div  style="width:100%;">
		<a title="UKRI - UK Research and Innovation" href="https://www.ukri.org/" target="_blank"><img style="max-width:150px;" class="cimage" src="pics/UKRI.png"></a>
		 </div>
		 
		  <div class="small-break"></div>
		 <div  class="homecontact" >
		   <p class="gold"><strong>Contact</strong></p>
		   <p class="gold">Coordinator:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:pzuch@fizyka.umk.pl"  class="gold">Piotr Zuchowski</a></p>
		    <p class="gold">Project Manager:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:a_wis@umk.pl"  class="gold">Agata Wiśniewska </a></p>
		 
		 </div>
		 <div class="small-break"></div>
		 <div  style="width:100%; padding-left:10px">
		   <p class="gold">Also find us on :</p>
		   
		   <ul class="social-list clearfix">
			
			<li> <a href="https://www.linkedin.com/company/85627029/admin/" target="_blank" class="circled"><i class="fa fa-linkedin"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
			<li> <a href="#" class="circled"><i class="fa fa-twitter"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
		  </ul>
	  
		 </div>
		 
      </div>
	  <!--
	   End of Right content
	  -->