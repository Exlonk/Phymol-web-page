<?php

include("include/classes/session.php");

mysqli_query($database->connection,"SET NAMES UTF8");
mysqli_query($database->connection,"set character set UTF8");
mysqli_query($database->connection,"set collation_connection='utf8_unicode_ci'");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 
</head>
<body class="sliphover-active border-bottom-on-header">
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.html">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <?php include("nav.php"); ?>
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		  <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">

			<?php
			
			$rowsPerPage = 5;

			// by default we show first page
			$pageNum = 1;

			// if $_GET['page'] defined, use it as page number
			if(isset($_GET['page']))
			{
				$pageNum = $_GET['page'];
			}

			// counting the offset
			$offset = ($pageNum - 1) * $rowsPerPage;
			
			$query = "";
			$query = "SELECT * FROM news where live = 1 ORDER BY id DESC LIMIT $offset, $rowsPerPage";  //$query = "SELECT * FROM hirek  where live = 1 and en = 1 ORDER BY id DESC LIMIT $offset, $rowsPerPage";

			//$query = "SELECT * FROM hirek  where live = 1 ORDER BY id DESC LIMIT $offset, $rowsPerPage";
			$show_results  = mysqli_query($database->connection,$query) or die(mysql_error());
			
			
			
			?>
			
		
			<div class="newssection">
			    <h1 class="postheader">News &amp; Events</h1>
				
				<?php while($row = mysqli_fetch_array($show_results)) { ?>
							
				<div class="anews">
					<img src="pics/default.jpg"  style="float: left; max-width:100px;">
					<p class="newstitle"><?php echo $row['title'] ?></p>
					<p class="newstext"><?php echo $row['text'] ?></p>
				</div>
				 <div class="clear"></div>
				<?php } ?>

				<?php 
				
				// how many rows we have in database
						$query = "";
						
						$query   = "SELECT COUNT(id) AS numrows FROM news where live = 1"; //
						
						$result  = mysqli_query($database->connection,$query) or die('Error, query failed');
						$row     = mysqli_fetch_array($result);
						$numrows = $row['numrows'];

						// how many pages we have when using paging?
						$maxPage = ceil($numrows/$rowsPerPage);

						// print the link to access each page
						$self = $_SERVER['PHP_SELF'];
						$self .="?var1=2";
						
						$pageM = 1;
						if ($pageNum > 1)
							$pageM  = $pageNum - 1;
							
						$nav  = "<ul class=\"pagination\"><li><a href=\"$self&page=$pageM\"><i class=\"fa fa-chevron-left\"></i></a></li>";
						
						for($page = 1; $page <= $maxPage; $page++)
						{
						   if ($page == $pageNum)
						   {
							  $nav .= "<li class=\"active\"><a href=\"#\">$page</a></li> "; // no need to create a link to current page
						   }
						   else
						   {
							  $nav .= "<li><a href=\"$self&page=$page\">$page</a></li> ";
						   } 
						}
						
						$pageP = $maxPage;
						if ($pageNum < $maxPage)
							$pageP = $pageNum + 1;
							
						$nav  .= "<li><a href=\"$self&page=$pageP\"><i class=\"fa fa-chevron-right\"></i></a></li></ul>";

						

						// print the navigation link
						//echo "<font size=\"4\">".$first . $prev . $nav . $next . $last."</font>";
						echo $nav;
					?>
				
				
			</div>
        
      </div>
	  
	  
	 <!--
	   Right content
	  -->
       <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
   </div>
   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
</div>
<!-- end wrapper --> 


<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/jquery.touchSwipe.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 
<script src="js/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script src="js/jquery.sliphover.min.js" type="text/javascript"></script>
</body>
</html>