<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 
	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.php">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
   <?php include("nav.php"); ?>
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		  <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
	  
			<h4 class="content-title">BENEFICIARIES</h4>
			
			<div class="small-break"></div>
			
			<div id="USC" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/USC.png"></div>
				
				<h4 class="bentitle pl170">University of Santiago de Compostela. Department of Physical Chemistry. Spain (USC)</h4>
				<p class="pl170">The University of Santiago de Compostela (USC, http://www.usc.es) is a public university founded in 1495. It offers a total of 52 bachelor degrees, 55 doctoral programs, and 59 master degrees. More than 2,000 professionals work at USC (about 38% female) and around 26,000 students per year. In 2016, USC was ranked among the top ten Spanish universi- ties. The Quantum Chemistry group is part of the Physical Chemistry Department since 1996.</p>
				<p class="pl170">Website: <a href="https://www.usc.gal/en" target="_blank">USC</a></p>
			    <p class="pl170">PHYMOL members: <br/>
					<a href="https://investigacion.usc.gal/investigadores/58934/detalle?lang=en" target="_blank" style="padding-left: 10px;">Prof. Berta Fernández Rodríguez</a><br/>
					<a href="https://investigacion.usc.gal/investigadores/60577/detalle?lang=en" target="_blank" style="padding-left: 10px;">Prof. Saulo A. Vázquez Rodríguez</a>
				
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="UL" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/UL.png"></div>
				
				<h4 class="bentitle pl170">University of Luxembourg (UL): Theoretical Chemical Physics group</h4>
				<p class="pl170">University of Luxembourg ranks 20th in the 2021 Times Higher Education Young University Ranking and 3rd worldwide in International Outlook. UL has 3100 employees, including 950 PhD candidates within three Doctoral Schools. The Doctoral School in Science & Engineering offers programs in Physics & Materials Science, Mathematics, Computer Science, Biology and Engineering, and Computational Sciences.</p>
				<p class="pl170">Website: <a href="https://wwwen.uni.lu/" target="_blank">UL</a></p>
			    <p class="pl170">PHYMOL member: <br/>
					<a href="https://wwwfr.uni.lu/recherche/fstm/dphyms/people/alexandre_tkatchenko" target="_blank" style="padding-left: 10px;">Prof. Alexandre Tkatchenko</a>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="RUN" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/RUN.png"></div>
				
				<h4 class="bentitle pl170">Radboud University Nijmegen (RUN): Theoretical Chemistry Group</h4>
				<p class="pl170">The RU Nijmegen, founded 1923, is situated in the oldest city in the Netherlands and is listed in the Dutch university information guide “Keuzegids Universiteiten” as the best Dutch general university 2019 of all the traditional general universities. The RU has grouped its research within research institutes with the aim of creating an optimal research environment which has focus and critical mass. The institute for Molecules and Materials (IMM) is an interdisciplinary research institute in chemistry and physics at the Faculty of Science of the RU and counts the Nobel laureates in Physics (2012, A. Geim and K. Novoselov) among its visiting professors. Its mission is to fundamentally understand, design and control the func- tioning of molecules and materials. Its unique experimental facilities, backed up by strong theoretical groups, together with a balanced educational programme, guarantee an excellent environment for training Ph.D. students and young scientists in these interdisciplinary fields of science.</p>
				<p class="pl170">Website: <a href="https://www.ru.nl/en" target="_blank">RUN</a></p>
				<p class="pl170">PHYMOL members: <br/>
					<a href="https://www.theochem.ru.nl/~tkarman/" target="_blank" style="padding-left: 10px;">Dr. Tijs Karma</a><br/>
					<a href="https://www.theochem.ru.nl/~gerritg/" target="_blank" style="padding-left: 10px;">Prof. Gerrit C. Groenenboom</a><br/>
					<a href="https://www.theochem.ru.nl/~avda/" target="_blank" style="padding-left: 10px;">Prof. Ad van der Avoird</a><br/>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="UMK" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/UMK.png"></div>
				
				<h4 class="bentitle pl170">Nicolaus Copernicus University in Torun (UMK)</h4>
				<p class="pl170">The Nicolaus Copernicus University in Torun ́ (NCU, since 1945). It is one of the largest universities in Poland. It provides graduate and postgraduate courses for almost 20,000 students. The Faculty of Physics, Astronomy and Informatics has state-of-the-art research infrastructure including the National Laboratory of Atomic, Molecular and Optical Physics (FAMO), the Center for Quantum Optics and the Interdisciplinary Center for Modern Technologies. The Faculty of Physics, Astronomy and Informatics is the top faculty at NCU Torun ́, which is ranked as 5th best university in Poland. The Faculty itself is ranked as the 5th best among the faculties of physics of all higher education institutions in Poland. Large amount of research in the institute focuses on spectroscopy - method development and application (in particular HITRAN database development) which is in line with PHYMOL. We are active partners in international programs (supported from government) for staff and student exchange in astronomy, atomic, molecular and chemical physics.</p>
				<p class="pl170">Website: <a href="https://www.umk.pl/en/" target="_blank">UMK</a></p>
			    <p class="pl170">PHYMOL member: <br/>
					<a href="http://fizyka.umk.pl/~pzuch/index.html" target="_blank" style="padding-left: 10px;">Dr. Piotr Zuchowski</a><br/>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="CSIC" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/CSIC.png"></div>
				
				<h4 class="bentitle pl170">CSIC: Agencia Estatal Consejo Superior de Investigaciones Científicas. Institute of Funda- mental Physics</h4>
				<p class="pl170">The Spanish National Research Council (CSIC) is the largest public institution dedicated to research in Spain and the third largest in Europe. Belonging to the Spanish Ministry of Sci- ence, Innovation and Universities through the State Secretariat for Research, Development and Innovation, CSIC addresses four key objetives: (1) to foster multidisciplinary scientific and technological research; (2) to promote knowledge transfer to industry and society; (3) to educate and train both scientific and technical staff; (4) to create technology-based companies. CSIC offers a variety of training and specialization programs that can be accessed based on the academic level: 1) Degree students: there are CSIC-Universities agreements so that the final degree projects can be carried out at CSIC’s research institutes as well as traineeships for students via Erasmus + programme; (2) Postgraduate students can benefit from (a) mentored research training at CSIC’s research institutes, (b) masters studies since there are stable collaboration of CSIC’s researchers in masters from several universities, (c) Erasmus Mundus Joint Master program; (3) Doctorate (PhD) the doctoral thesis can be led by a CSIC’s researcher in a CSIC’s research institute.</p>
				<p class="pl170">Website: <a href="https://www.csic.es/en/csic" target="_blank">CSIC</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="http://www.abinitsim.iff.csic.es/mariapilardelaracastells" target="_blank" style="padding-left: 10px;">Dr. M. Pilar de Lara-Castells</a><br/>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="SU" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/SU.png"></div>
				
				<h4 class="bentitle pl170">Sorbonne Université (SU)</h4>
				<p class="pl170">Born from the merger of Universite ́ Pierre et Marie Curie and Universite ́ Paris Sorbonne, whose campuses are in the heart of Paris, Sorbonne Universite ́ covers all major disciplinary fields and offers new transversal academic and research programs. Sorbonne Universite ́ becomes a fully multidisciplinary research-intensive university with three faculties: Human- ities and Social Sciences, Medicine and Sciences & Engineering. With more than 55,600 students (among 10,200 international students), 4700 doctoral students and 6400 researchers, Sorbonne Universite ́ is one of the leading French universities.</p>
				<p class="pl170">Website: <a href="https://www.sorbonne-universite.fr/en" target="_blank">SU</a></p>
				<p class="pl170">PHYMOL members: <br/>
					<a href="https://piquemalresearch.com/" target="_blank" style="padding-left: 10px;">Prof. Jean-P. Piquemal</a><br/>
					<a href="https://scholar.google.fr/citations?user=Iuujj6sAAAAJ&hl=fr" target="_blank" style="padding-left: 10px;">Dr. Louis Lagardere</a>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="ELTE" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/ELTE.png"></div>
				
				<h4 class="bentitle pl170">ELTE: Eötvös Lorand University, Complex Chemical Systems Research Group</h4>
				<p class="pl170">Eötvös Loránd University (ELTE) is Hungary’s most prestigious university with the richest traditions and the highest international rankings in the country. In recognition of this, ELTE became a Research University in 2010 and received the distinguished title of University of National Excellence in 2013, which attests to educational and research capacities, scientific outputs, and its wide-ranging international relations. With 8 faculties, 96 master’s degree programs, more than 50 foreign-language programs, 76 academic lecturers (20% of all Hungarian academics), 16 PhD schools, 118 PhD programs, 25 800 students from more than 70 different countries ELTE offers the widest range of higher education options in Hungary.</p>
				<p class="pl170">Website: <a href="https://www.elte.hu/en/" target="_blank">ELTE</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="http://csaszar.chem.elte.hu/" target="_blank" style="padding-left: 10px;">Prof. Attila G. Császár</a><br/>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="AMS" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/AMS.png"></div>
				
				<h4 class="bentitle pl170">AMS : Avantgarde Materials Simulations</h4>
				<p class="pl170">AMS is the world-leading provider of software for crystal structure prediction (CSP) and crystal structure prediction contract research. AMS sells software and services to about 2/3 of the 20 largest pharmaceutical companies. AMS’ success hinges on a unique combination of academic curiosity, moral integrity, technical excellence and industry focus.</p>
				<p class="pl170">Website: <a href="https://www.avmatsim.eu/" target="_blank">AMS</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://www.researchgate.net/profile/Marcus-Neumann-2" target="_blank" style="padding-left: 10px;">Dr. Marcus Neumann</a><br/>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			

			
			
			
			


        
      </div>
	  
	  
	   <!--
	   Right content
	  -->
      <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
 

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 

<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/jquery.touchSwipe.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 
<script src="js/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script src="js/jquery.sliphover.min.js" type="text/javascript"></script> 



</body>
</html>