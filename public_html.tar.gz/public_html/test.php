<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="Sugarland – Contemporary Portfolio for Creatives that Stands Out" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.html">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <!-- start main nav -->
    <nav id="main-nav">
      <ul class="option-set clearfix" data-option-key="filter">
        <li> <a href="index.html">HOME</a></li>
        <li > <a href="project.html">PHYMOL PROJECT</a> </li>
         <li > <a href="#" class="sub-nav-toggle">PHYMOL NETWORK</a>
          <ul class="sub-nav hidden">
            <li > <a href="beneficiaries.html" >Beneficiaries</a> </li>
            <li> <a href="partners.html">Partners</a> </li>
			<li> <a href="members.html" >Members</a> </li>
          </ul>
        </li>
         <li> <a href="research.html">POSITIONS</a> </li>
      </ul>
    </nav>
    <!-- end main nav -->
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		 <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
			
			<?php
			$servername = "localhost";
			$username = "hqbfdjsr_root";
			$password = "qYHQxYop34b";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
			  die("Connection failed: " . $conn->connect_error);
			}
			echo "Connected successfully";
			?>
        
      </div>
	  
	  
	   <!--
	   Right content
	  -->
      <div class="col-md-3 col-sm-8 ">
        <div class="small-break"></div>
        <div class="boxed keys">
          <p><strong>Key Facts</strong></p>
         
          <ul class="clearfix keysul">
              <li> Scientific beneficiaries: 10 </li>
            <li> Partners: 6 </li>
            <li> Number of countries involved: 10 </li>
            <li> Budget: approx. €2.6M from Horizon Europe and €300K from UKRI. </li>
            <li> Number of funded doctoral candidates: 11 </li>
            <li> Coordinated by Prof Piotr Zuchowski from Universytet Mikłaja Kopernika, Torun </li>
            <li> PHYMOL is a doctoral network funded mainly under the Horizon Europe scheme, and also by the UK Research and Innovation</li>
          </ul>
        </div>
		
		<div  style="width:100%;">
		<a title="ITN - Marie Curie Actions" href="https://marie-sklodowska-curie-actions.ec.europa.eu/" target="_blank"><img style="max-width:150px;" class="cimage" src="pics/EC.png"></a>
		 
		 </div>
		  <div class="small-break"></div>
		 <div  class="homecontact" >
		   <p class="gold"><strong>Contact</strong></p>
		   <p class="gold">Coordinator:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:pzuch@fizyka.umk.pl"  class="gold">Piotr Zuchowski</a></p>
		    <p class="gold">Project Manager:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:a_wis@umk.pl"  class="gold">Agata Wiśniewska </a></p>
		 
		 </div>
		 <div class="small-break"></div>
		 <div  style="width:100%; padding-left:10px">
		   <p class="gold">Also find us on :</p>
		   
		   <ul class="social-list clearfix">
			
			<li> <a href="https://www.linkedin.com/company/85627029/admin/" target="_blank" class="circled"><i class="fa fa-linkedin"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
			<li> <a href="#" class="circled"><i class="fa fa-twitter"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
		  </ul>
	  
		 </div>
		 
      </div>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 


<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script> 
<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 




</body>
</html>