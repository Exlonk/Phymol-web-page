
   <!-- start main nav -->
    <nav id="main-nav">
      <ul id="navul" class="option-set clearfix" data-option-key="filter">
        <li> <a href="index.php">HOME</a></li>
        <li> <a href="project.php">PHYMOL PROJECT</a> </li>
        <li> <a href="#" class="sub-nav-toggle">PHYMOL NETWORK</a>
          <ul class="sub-nav hidden">
            <li > <a href="beneficiaries.php" >Beneficiaries</a> </li>
            <li> <a href="partners.php" >Partners</a> </li>
			<li> <a href="members.php" >Members</a> </li>
          </ul>
        </li>
        <li> <a href="research.php">PROJECTS</a> </li>
        <li> <a href="recruitment.php">RECRUITMENT</a> </li>
        <li> <a href="events.php">EVENTS</a></li>
        <li> <a href="training.php">TRAINING</a> </li>
        <li> <a href="impact.php">IMPACT</a> </li>
		
		 <?php if (($session->logged_in)) { ?>
			<li><a href="admin.php" style="color:red;">ADMIN</a></li>
			<li><a href="process.php" style="color:red;">LOGOUT</a></li>
		<?php } ?>
      </ul>
	  
	  <p><a href="calendar.php" style="border:0;"><i class="fa fa-calendar" style="color:white;" aria-hidden="true"></i>PHYMOL Calendar</a></p>
    </nav>
    <!-- end main nav -->
	
	<script>
		$( document ).ready(function() {
			var url = window.location.pathname;
			var filename = url.substring(url.lastIndexOf('/')+1);
			//alert(filename);
			
			if(filename == "" || filename == "index.php")
				$("#navul li").eq(0).addClass( "active" );

			if(filename == "project.php")
				$("#navul li").eq(1).addClass( "active" );
			
			if(filename == "beneficiaries.php")
				$("#navul li").eq(2).addClass( "active" );
			
			if(filename == "partners.php")
				$("#navul li").eq(2).addClass( "active" );
			
			if(filename == "members.php")
				$("#navul li").eq(2).addClass( "active" );
			
			if(filename == "research.php")
				$("#navul li").eq(6).addClass( "active" );
			
			if(filename == "recruitment.php")
				$("#navul li").eq(7).addClass( "active" );
			
			if(filename == "events.php")
				$("#navul li").eq(7).addClass( "active" );
				
			if(filename == "training.php")
				$("#navul li").eq(8).addClass( "active" );
			
			if(filename == "impact.php")
				$("#navul li").eq(9).addClass( "active" );

			
		});
	</script>