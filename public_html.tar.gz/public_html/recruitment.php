<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script> 	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.html">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <?php include("nav.php"); ?>
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		 <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
			<h4 class="content-title" id="title">Why apply to PHYMOL?</h4>
			<div class="small-break"></div>
			<p style="text-align:justify;">PHYMOL is a doctoral network that combines training and research in almost equal parts. Further, the network is built around a community of leading researchers and all doctoral candidates will be part of this community through secondments, training schools, PHYMOL events, and conferences. Here’s what you could stand to get from PHYMOL:</p>
			<ul class="clearfix recul">
              <li> The chance to participate in workshops and conferences. </li>
            <li> To interact with international laboratories and industrial partners. </li>
            <li> To perform cutting-edge research in a community of excellent researchers, both academic and industrial.</li>
            <li> To be involved with cool science that combines fundamental physics, chemical physics, models, machine-learning, and applying to challenging problems.</li>
            <li> To be able to travel to partners, conferences, laboratories. </li>
           
          </ul>
		  
		  <div id="mp-accordion-1" data-children=".mp-accordion-item" class="mp-accordion">
				
				     <!-- ACCORDION ITEM 1 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-1" aria-expanded="false" aria-controls="mp-accordion-item-1">Conditions for all applicants</a>
                        <div id="mp-accordion-item-1" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								<ul class="clearfix recul">
									<li> <strong>Nationality</strong>: We welcome applicants of any nationality. </li>
									<li> <strong>Degree</strong>: We strongly recommend applicants must hold a MSc or equivalent degree in the field of physics, chemistry, or chemical engineering. If you have another degree and are very interested in our projects get in touch with us (see contact information). <br><u>Note that you cannot already have a PhD degree.</u> </li>
									<li> <strong>Skills</strong>: Applicants must have the necessary academic skills and background to make the success of a doctoral degree. The skills needed will depend on the project chosen, but will normally include a good theoretical and mathematical background, and a strong ability in programming, or a willingness to learn programming techniques.</li>
									<li> <strong>MSCA Mobility Rule</strong>: Researchers must not have resided or carried out their main activity (work, studies, etc.) in the country of the host organisation for more than 12 months in the 3 years immediately before the recruitment date. Compulsory national service, short stays such as holidays, and time spent as part of a procedure for obtaining refugee status are not taken into account.</li>
									
								   
								</ul>
								
								<p>Additional conditions may apply and these will normally be specific to individual candidates and particular institutes:</p>
								
								<ul class="clearfix recul">
									<li> <strong>Local institute requirements</strong>: Additionally, DC applicants must fulfil the local requirements of the recruiting institutions. </li>
									<li> Applicants must be eligible to enrol on a PhD programme at the host institution (or at a designated university in case the host institution is a non-academic organisation).</li> 
								</ul>
								
								<p>Due to the nature of the PHYMOL network and our research requirements we have the following specific requirements from candidates:</p>
								
								<ul class="clearfix recul">
									<li>A Masters’ degree (MSc, MSci, Euro Masters, or equivalent) in physics, chemistry or related subjects. </li>
									<li>A proficiency in English. Non-EU applicants may need to provide evidence of language skills. </li> 
									<li>A solid background in physics/chemistry with a strong mathematical foundation. </li> 
									<li>Experience in programming (Python, and possibly Fortran95/C++) or a strong willingness to learn programming. </li> 
									<li>Experience or exposure to Linux/Unix would be welcome as this will prove essential. </li> 
									<li>An ability to work with others and an interest in scientifically engaging with different people and institutes. </li> 
								</ul>
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 2 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-2" aria-expanded="false" aria-controls="mp-accordion-item-2">The application procedure</a>
                        <div id="mp-accordion-item-2" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
								<p style="text-align:justify;">First of all, if you are interested in applying for projects in PHYMOL, make a short list of projects you are interested in. These can be found on the <a href="https://phymol.eu/research.php">PROJECTS</a> tab on our web page. These projects are linked to particular researchers and institutes, so please get in touch with those researchers using the contact details provided. You will benefit from this contact in writing the motivational letter.</p>	
								
								<p style="text-align:justify;">Official recruitment for PHYMOL begins only on the 1st of February 2023, but you can use the following process to pre-register your interest in PHYMOL projects, and also deposit your documents with us. There will be no advantage to putting in an early application other than that this will give you time to establish contact with the project supervisors and thereby learn more about the projects. </p>
								
								<ul class="clearfix appul">
									<li>Fill in the <a href="https://forms.gle/G5TDHb8s3dpxmbKE9" target="_blank" style="text-decoration: underline;">Recruitment form</a> (online) and submit it.</li>
									<li><strong>Compile your documents in one PDF file</strong>, following the order: </li>
									<ul class="clearfix subappul">
									   <li><strong>Motivation letter of no more than 2 pages (see below for some suggestions for this letter),</strong></li>
									   <li><strong>CV,</strong></li>
									   <li><strong>Copies of transcripts of any obtained degrees (please include translations into English, if needed), and</strong></li>
									   <li><strong>Contact details (names, email, university) of two academic referees. Please ensure that you have informed your referees about your application.</strong></li>
									</ul>
									<li>Make sure that the application is written in English.</li>
									<li>Submit all the above documents via e-mail <strong>as a single pdf file</strong> to <a href="mailto:phymol@umk.pl" style="text-decoration: underline;">phymol@umk.pl</a>. If you have trouble joining the files into one, submit them as separate files with file names that make it clear what is contained. The file name/s should include your name, e.g., GJ_Williams__CV.pdf.</li>
									<li>As the subject of your email, please use <strong>PHYMOL application:  your name.</strong></li>
									<li>The individual DC projects are set to start between (DD.MM.YYYY): <strong>15.03.2023 and 01.09.2023.</strong></li>
									<li><strong>APPLICATION DEADLINE: The initial deadline is 01.03.2023, after which we will start the recruitment process, but we may accept applications after this date, until all positions are filled.</strong></li>
									<li><strong>
									    APPLICATION DEADLINE EXTENDED for DC5 and DC6: As we are still recruiting for these positions, we will accept applications until they are filled. 
									</strong></li>
								</ul>
								
								<p style="font-size:15px; color:gray">Motivation letter: what should it contain?</p>
								<p>Here are some of the things we will look for in the motivation letter you provide:</p>
								<ul class="clearfix recul">
									<li>Your background: Information on projects you have conducted as part of your undergraduate degree.</li>
									<li>Your experience: Any special courses, or internships you have participated in that have given you skills that could be useful in PHYMOL.</li> 
									<li>Your choice of projects: Which projects have you selected?</li> 
									<li>Reasons for these choices: Why have you selected these? What is it that you find interesting? Perhaps you have read some of the research papers included in the project descriptions (remember you can always ask project supervisors for these if you can’t access them), in which case, maybe there is something in these papers that you find interesting.</li> 
									<li>Why PHYMOL?: The PHYMOL Doctoral Network is special and differs from most PhD schools in the breadth of skills we want to address. Why have you chosen PHYMOL? Was there something about it that caught your attention? We’d like to know. </li> 
									
								</ul>
								
								<p style="text-align:justify;"><i>Keep this letter to no more than 2 pages of 11pt fonts</i>. The purpose of this letter is to allow us to get an idea of who you are and to gauge your level of interest in PHYMOL. So make sure it does just that.</p>
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 3 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-3" aria-expanded="false" aria-controls="mp-accordion-item-3">The Selection process</a>
                        <div id="mp-accordion-item-3" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
								<p style="text-align:justify;">The PHYMOL selection procedure for DCs will be open, transparent, merit-based and in line with the <a href="https://euraxess.ec.europa.eu/jobs/charter/code" target="_blank">Code of Conduct for the Recruitment of Researchers</a>.</p>
								
								<ul class="clearfix recul">
									<li>After the initial deadline of the application process on <strong>01.03.2023</strong> which has been <strong>extended for DC5 and DC6</strong>, we aim to review and rank all documents within 2 to 3 weeks, though it is possible that the timeframe could change for individual cases. </li>
									<li>We will make a short-list of between 6 to 12 applicants per research post.</li>
									<li>This short-list will be determined on the basis of the submitted material, that is, on the candidate’s qualifications, prior experience, letters of reference, and the letter of motivation. </li>
									<li>Shortlisted applicants will be invited for interviews. These will normally be online.</li>
									<li>Those not selected will be informed.</li>
									<li>The interview panels will consist of the project PIs and others from the PHYMOL team. We will attempt to make the panel as diverse as possible.</li>
									<li>Candidates will be ranked and invited to join PHYMOL in order of their ranking. This process may take a few weeks.</li>
									<li>We will keep a small number of candidates on a reserve list just in case candidates pull out before the final recruitment stage.</li>
									<li>Successful candidates will be informed as soon as possible after the interview.</li>
									<li><strong>Successful candidates will receive a country-dependent financial package including mobility and family allowance</strong> (the latter, if applicable) and will be employed according to the rules for Early Stage Researchers in and Marie Skłodowska-Curie Actions Doctoral Network (DN) and the general regulations of each host institution. This will apply to all candidates, including the one funded through UKRI. </li>
									<li>Successful candidates will be subsequently enrolled onto the PhD programmes of appropriate universities. This is a separate process that may require additional documentation and possibly qualifications like language tests. These will be made known to candidates.</li>
									<li>MSCA/UKRI <strong>will cover three years of full-time research</strong>, but final contract length and extension options depend on the host institution. We already expect some of the positions to be funded for 4 years, and others may be extended on a case-by-case basis.	</li>
									
								</ul>
									
                            </div>
                        </div>
                    </div>
					
					
					
			</div>
			<div class="small-break"></div>
			<p style="font-size:15px; font-weight:900">Contact</p>
			<p>After filling in the Recruitment form (see ‘The application procedure’ above), please <strong>send your full application or any queries to</strong> <a href="mailto:phymol@umk.pl" style="color: blue">phymol@umk.pl</a>. In case of any inquiries about open positions and recruitment, please contact us via this email.</p>
			
			<div class="small-break"></div>
			<p style="font-size:15px; font-weight:900">Timelines</p>
			<ul class="clearfix recul">
				<li>Accepting pre-applications: immediately.</li>
				<li>Initial application deadline: <strong>01.03.2023 (not applicable to DC5)</strong></li>
				<li>
				    <strong>
					Application deadline for DC5 has been extended and we continue to accept applications.
    				</strong>
				    Candidates wanting to apply for these positions please contact the PI of the project:
				        <a href="mailto:marcus.neumann@avmatsim.eu" style="color: blue">Marcus Neumann:  (Marcu(pzuch@fizyka.umk.pl) DOT neumann AT avmatsim DOT eu) </a>, or
				        the coordinator <a href="mailto:pzuch@fizyka.umk.pl" style="color: blue"> Piotr Zuchowski (pzuch@fizyka.umk.pl)</a>, and
				</li>
				<li>Start date for doctoral candidates: Between 15.03.2023 and 01.09.2024</li>
			</ul>
			
      </div>
	  
	  
	   <!--
	   Right content
	  -->
     	 <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 



<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 




</body>
</html>