<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.php">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <!-- start main nav -->
	<?php include("nav.php"); ?>
    <!-- end main nav -->
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		  <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
	  
			<h4 class="content-title">RESEARCH PROJECTS</h4>
			
			<p>
			All doctoral candidates (DCs) will be paid a generous salary on EU rates (these depend on the country in which the DC will be based, but are in excess of €3K per month),  and will include mobility and family allowances. Normally, all DCs are funded for 36 months, but DC2 and DC7 will be funded for 48 months. 
			<br/><br/>
			
			For information on the Application Process will be posted soon, but for inquiries into PHYMOL as a whole, or individual projects please contact the coordinator (email on the Contact section), or individual PIs (see on <a href="members.php">Members</a> website). 
			<br/><br/>	

			</p>
				
				     <div id="mp-accordion-1" data-children=".mp-accordion-item" class="mp-accordion">
				
				    
				     <!-- ACCORDION ITEM 1 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-1" aria-expanded="false" aria-controls="mp-accordion-item-1">DC1: Towards the accurate description of the induction energy in SAPT</a>
                        <div id="mp-accordion-item-1" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#UMK"> Nicolaus Copernicus University in Torun (UMK)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: Introduce systematically improvable theory for dispersion-free interaction between two monomers. This will be done by extension of the
SAPT framework to include excited-state, open-shell systems. Special care will be taken to ensure that the induction energy is accurate as it is known to be
problematic for neutral systems, and problems will be worse when excited states are present.<br/>
										<b>Supervisor</b>: <a href="members.php#zuchowski" >Dr. Piotr Zuchowski (UMK)</a> <br/>
										<b>Co-supervisor</b>: <a href="members.php#otero">Dr. Rachel Crespo-Otero </a>  and <a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
										<b>Mentor</b>:<a href="members.php#BertaFR" >Prof. Berta Fernández Rodríguez (USC)</a> <br/>
										<b>Further information</b>: <a href="DCs.php?dc=1">Project details of DC1</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
			
					<!-- ACCORDION ITEM 2 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-2" aria-expanded="false" aria-controls="mp-accordion-item-2">DC2: Intermolecular interactions in excited states: the CO–CO* and other excimers</a>
                        <div id="mp-accordion-item-2" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#ELTE"> Eötvös Loránd University (ELTE)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: One of the aims of the project is to benchmark electronic structure methods on complexes in electronically excited states. The initial focus will be on the CO-CO* excimer spectrum, as it can be studied in full dimensionality. The ground state has already been studied and the excimer spectrum can be measured. Start with calculations of diabatic interaction potentials for the CO-CO* excimer with existing electronic structure methods and with the SAPT and SAPT(DFT) methods for the CO-CO* excimer and the computation of the CO-CO* excimer spectrum. Apply SAPT-based methods to larger complexes such as the benzene dimer. Results from DC1 will be used if possible..<br/>
										<b>Supervisor</b>:<a href="members.php#AGC">Prof. Attila G. Császár (ELTE)</a><br/>
										<b>Co-supervisor</b>:<a href="members.php#Groenenboom" >Prof. Gerrit Groenenboom (RUN)</a><br/>
										<b>Mentor</b>: <a href="https://lweb.cfa.harvard.edu/~igordon/" target="_blank" >Dr. Iouli E. Gordon (HITRAN)</a> <br/>
										<b>Further information</b>: <a href="DCs.php?dc=2">Project details of DC2</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 3 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-3" aria-expanded="false" aria-controls="mp-accordion-item-3">DC3: Collision-induced absorption spectra calculated from ab initio potentials </a>
                        <div id="mp-accordion-item-3" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#RUN"> Radboud University Nijmegen (RUN)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 48 months<br/>
										<b>Objectives</b>: To develop computational techniques for quantum mechanical nuclear motion to benchmark ab initio interaction potentials and to employ these to compute collisioninduced absorption (CIA) spectra used by (exo)planetary scientists. You will use ab initio methods such as SAPT(DFT) for computing ab initio potentials for molecular dimers, and use these to compute CIA spectra of complexes of interest such as O2-CO2 , CO2-H2, CO2-CO2, CH4-CO2, CH4-CH4, and CH4-N2. The spectra will be included into the HITRAN database, often used by scientists studying the terrestrial and planetary atmospheres. These results will be incorporated into atmospheric models and in the analysis of satellite data taken to monitor the atmosphere.<br/>
										<b>Supervisor</b>: <a href="members.php#Karman" >Dr. Tijs Karman (RUN)</a> <br/>
										<b>Co-supervisor</b>: <a href="members.php#zuchowski" >Prof. Piotr Zuchowski (UMK)</a> <br/>
										<b>Mentor</b>:<a href="https://lweb.cfa.harvard.edu/~igordon/" target="_blank" >Dr. Iouli E. Gordon (HITRAN)</a><br/>
										<b>Further information</b>: <a href="DCs.php?dc=3">Project details of DC3</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 4 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-4" aria-expanded="false" aria-controls="mp-accordion-item-4">DC4: Reparametrisation of semiempirical models</a>
                        <div id="mp-accordion-item-4" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#USC">University of Santiago de Compostela (USC)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: The aim is to iteratively improve the PM6 Hamiltonian that is implemented in the MOPAC2016 program. This will be done using a database
of reference DFT+D and coupled-cluster (CC) intermolecular interaction energies calculated for a set of specially chosen small molecules representing
important functional groups. Correction to the PM6 model will be evaluated from this data set, and an analytical correction function will be obtained
through fitting. Subsequent data sets containing larger molecules, with more complex functional units, will be added and the corresponding fits will be
carried out. After validation, the method will be applied to the study of other systems.<br/>
										<b>Supervisor</b>: <a href="members.php#SauloVR" >Prof. Saulo A. Vázquez Rodríguez (USC)</a>  and <a href="members.php#BertaFR" >Prof. Berta Fernández Rodríguez (USC)</a> <br/>
										<b>Co-supervisor</b>: <a href="members.php#Tkatchenko" >Prof. Alexandre Tkatchenko (UL)</a> <br/>
										<b>Mentor</b>: <a href="members.php#Castells" >Dr. M. Pilar de Lara-Castells (CSIC)</a> <br/>
										<b>Further information</b>: <a href="DCs.php?dc=4">Project details of DC4</a> <br/>
									</p>
									
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 5 -->
                    <div class="mp-accordion-item">
                        
						<a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-5" aria-expanded="false" aria-controls="mp-accordion-item-5">
						DC5: AI/ML assisted parameter generation for an ab-initio-grade force field covering all mainstream organic chemistry
						</a>

                        <div id="mp-accordion-item-5" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#SU">Avantgarde Materials Simulations (AMS)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: As soon as possible <br/>
										<b>Duration</b>: To be decided (up to 36 months) <br/>
										<b>Objectives</b>: Tailor-made Force Fields (TMFFs), i.e. parametric force fields fitted fully 
										automatically from scratch to ab initio data, have strongly contributed to AMS' 
										success in the field of Crystal Structure Prediction (CSP) and are also available for use 
										in third-party software through the Force Field Factory module in AMS‘ GRACE code. Because 
										of their unique speed-accuracy compromise, parametric force fields will continue to play a 
										role even when Machine Learning (ML) force fields will become generally applicable. The goal 
										of the project is twofold: improve the mathematical framework of tailor-made force fields to 
										further approach ab initio accuracy and reduce the CPU time requirements of the parameterization 
										procedure.<br/>

										<b>Supervisor</b>: <a href="members.php#Neumann" >Dr. Marcus Neumann (AMS)</a> <br/>
										<b>Co-supervisor</b>:  <a href="members.php#Tkatchenko" >Prof. Alexandre Tkatchenko (UL)</a><br/>
										<b>Mentor</b>:<a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
										<b>Further information</b>: <a href="DCs.php?dc=5">Project details of DC5</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 6 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-6" aria-expanded="false" aria-controls="mp-accordion-item-6">DC6: Consistent treatment of polarization and charge-delocalization in many-body systems</a>
                        <div id="mp-accordion-item-6" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#SU">Sorbonne Université (SU)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: The ISA, ISApol and regularized-SAPT(DFT) techniques developed by Misquitta et al. have been successfully used in constructing accurate
many-body polarization models for molecular simulations of complexes which are strongly polarizable. But these techniques do not yet treat systems
with conformational flexibilty and do not treat charge-delocalization consistently. In this project we aim to fix both problems and implement solutions
in Tinker-HP. 1) Develop and/or collect reference many-body data on small molecular clusters and single molecule properties for flexible molecules.
2) Establish state-of-the-art by comparisons against models developed using Reg-SAPT(DFT), AMOEBA, and other relevant polarizable force-fields. 3)
Develop theoretical framework for bare multipoles and polarizabilities which, when coupled, are able to reproduce reference properties from (1). 4) Develop
consistent model for many-body charge-delocalisation based on unified reg-SAPT(DFT) and Thole-damped classical polarizable models. 5) Benchmark
models against reference data from (1) and apply to molecular crystals in Tinker-HP.<br/>
										<b>Supervisor</b>: <a href="members.php#Piquemal" >Prof. Jean-P. Piquemal (SU)</a> and <a href="members.php#Lagardere">Dr. Louis Lagardere (SU)</a> <br/>
										<b>Co-supervisor</b>: <a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
										<b>Mentor</b>: <a href="members.php#Neumann" >Dr. Marcus Neumann (AMS)</a><br/>
										<b>Further information</b>: <a href="DCs.php?dc=6">Project details of DC6</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 7 -->
                    <div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-7" aria-expanded="false" aria-controls="mp-accordion-item-7">DC7: How intermolecular interactions shape polymorphic energy landscapes</a>
                        <div id="mp-accordion-item-7" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#UL">University of Luxembourg (UL)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: We have shown that the DFT+MBD approach can deliver quantitative relative energies of polymorphic molecular crystals of pharmaceutical
interest (Hoja et al., Science Advances (2019)). Next we need to understand the interplay of different interactions that characterize polymorphic energy
landscapes. This is crucial for drug formulation. The DC will construct a systematic set of molecules (from small to large; varying functional groups)
and calculate their polymorphic energy landscapes using the DFT+MBD method. This will lead to both fundamental understanding of structure-property
relations in molecular crystals and provide useful guidance for pharmaceutical development.<br/>
										<b>Supervisor</b>:  <a href="members.php#Tkatchenko" >Prof. Alexandre Tkatchenko (UL)</a><br/>
										<b>Co-supervisor</b>: <a href="members.php#Neumann" >Dr. Marcus Neumann (AMS)</a><br/>
										<b>Mentor</b>: <a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
										<b>Further information</b>: <a href="DCs.php?dc=7">Project details of DC7</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 8 -->
					<div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-8" aria-expanded="false" aria-controls="mp-accordion-item-8">DC8: State-of-the art modelling of new quantum materials: surface-supported metal atomic quantum
clusters</a>
                        <div id="mp-accordion-item-8" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#CSIC">Agencia Estatal Consejo Superior de Investigaciones Científicas (CSIC)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: State-of-the-art modelling of the interaction of metal atomic quantum clusters AQCs (in either air, solution, or helium droplets) with the surface
of technologically relevant materials, making the emphasis on the new optical and (photo-)catalytic properties acquired by the support as well as the the
stability of the supported AQCs at high temperatures and oxygen pressures. A critical task is the development of accurate interaction models, particularly of
the dispersion interaction, which are capable to characterising the interaction of the confined object (AQCs) by the confining environments, and also account
for excitations. The proposed study is expected to provide basic, mechanistic information, and key simplifications that can be transferred to the reactions of
industrial applications with the help of machine learning technologies.<br/>
										<b>Supervisor</b>:<a href="members.php#Castells" >Dr. M. Pilar de Lara-Castells (CSIC)</a> <br/>
										<b>Co-supervisor</b>: <a href="members.php#Hernando" target="_blank" >Dr. Alberto Hernando (KIDO)</a> <br/>
										<b>Mentor</b>: <a href="members.php#zuchowski" >Dr. Piotr Zuchowski (UMK)</a> <br/>
										<b>Further information</b>: <a href="DCs.php?dc=8">Project details of DC8</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 9 -->
					<div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-9" aria-expanded="false" aria-controls="mp-accordion-item-9">DC9: Implicit machine-learning solvent models for confined spaces.</a>
                        <div id="mp-accordion-item-9" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#AMS">Avantgarde Materials Simulations (AMS)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: The goal is to pave the way for the the crystal structure prediction of pocket and channel solvates (in particular hydrates) by the development
of an implicit solvent model that yields reliable results even when the motion of the solvent molecules is restrained by the boundaries of the crystal cavity in
which their motion takes place. Steps: 1) Develop atomistic methods to assess the free energy of solvent pockets and channels against experimental stability
information for solvates and neat forms. 2) Design and implement an automated procedure for the atomistic modelling calculation of the free energy of
solvate pockets and channels for experimental crystal structures (from crystallographic databases) and/or putative crystal structures (from CSP). 3) Develop
and parameterize a machine-learning implicit solvent model that assesses the pocket and channel free energy taking the cavity shape, size and surface charge
density distribution as input.<br/>
										<b>Supervisor</b>: <a href="members.php#Neumann" >Dr. Marcus Neumann (AMS)</a><br/>
										<b>Co-supervisor</b>:  <a href="members.php#Tkatchenko" >Prof. Alexandre Tkatchenko (UL)</a><br/>
										<b>Mentor</b>: <a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
										<b>Further information</b>: <a href="DCs.php?dc=9">Project details of DC9</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 10 -->
					<div class="mp-accordion-item">
                        <a class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-10" aria-expanded="false" aria-controls="mp-accordion-item-10">DC10:
								Machine learning and quantum mechanics applied to predicting fluorescence quantum yield </a>
                        <div id="mp-accordion-item-10" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#UMK">Nicolaus Copernicus University in Torun (UMK)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: Developing a deep understanding of the factors affecting the
															fluorescence quantum yield in condensed phase and establishing the
															theoretical tools for its prediction based on the application of the machine
															learning techniques. 1) Design and implementation of automated procedures to analyse the effect of
															the environment on energies, forces and nonadiabatic couplings. 2) Application of the data-driven approach for the exploration of the role of
															intermolecular interactions in the excited state. 3) Implementation of ML models to account for the effect of intermolecular
															interactions in excited state calculations for FQY prediction.

														<br/>
										<b>Supervisor</b>: <a href="members.php#Hernando"  >Dr. Anna Kaczmarek-Kędziera (UMK)</a> <br/>
										<b>Co-supervisor</b>: <a href="members.php#Castells" >Dr. Rachel Crespo-Otero (UCL)</a><br/>
										<b>Mentor</b>: <a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					<!-- ACCORDION ITEM 11 -->
					<div class="mp-accordion-item">
                        <a id="dc11" class="mp-accordion-title collapsed" data-toggle="collapse" data-parent="#mp-accordion-1" href="#mp-accordion-item-11" aria-expanded="false" aria-controls="mp-accordion-item-11">DC11: Density-mapped FFs: Rapid prototyping of force-fields based on physical and ML mappings
onto the electronic density</a>
                        <div id="mp-accordion-item-11" class="collapse" role="tabpanel">
                            <div class="mp-accordion-content"> 
								
									<p class="col p-2 m-0">
									    <b>Host</b>: <a href="beneficiaries.php#QMUL" >Queen Mary University of London (QMUL)</a><br/>
										<b>PhD Enrolment</b>: Yes<br/>
										<b>Start date</b>: Month 8<br/>
										<b>Duration</b>: 36 months<br/>
										<b>Objectives</b>: 1) Derive a unified theoretical framework for the mapping of terms in physically motivated FFs onto properties of the atoms-in-a-molecule
										(AIM) densities. 2) Derive and implement robust methods for extraction of AIM properties based on the basis-space ISA (iterated stockholder atoms)
										algorithm. 3) Derive methods to approximate the polarization damping and charge-delocalisation energies based on AIM properties (first and second-order).
										4) Implement all methods in an open-source Python code. 5) Combine the physics-based models with ML to make improved mappings between AIM
										properties and optimized FF parameters. 6) Apply the resulting models in Tinker-HP for test systems for which accurate reference data is available (e.g.
										pyridine dimer and complexes involving water).<br/>
										<b>Supervisor</b>:<a href="members.php#misquitta" >Dr. Alston J. Misquitta (QMUL)</a><br/>
										<b>Co-supervisor</b>:  <a href="members.php#Tkatchenko" >Prof. Alexandre Tkatchenko (UL)</a><br/>
										<b>Mentor</b>: <a href="members.php#BertaFR" >Prof. Berta Fernández Rodríguez (USC)</a><br/>
										<b>Further information</b>: <a href="DCs.php?dc=11">Project details of DC11</a> <br/>
									</p>
									
								
                            </div>
                        </div>
                    </div>
					
					
					
				<!-- acc end -->
				</div>
			
        
      </div>
	  
	  
	  
	   <!--
	   Right content
	  -->
     <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 


<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 

<script>

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
    return false;
};

$( document ).ready(function() {
    var url_string = window.location.search;
	//var url = new URL(url_string);
    var dc = getUrlParameter("dc");
	
	
	
	if(dc != false )
	{
	    var target = "mp-accordion-item-"+dc;
		
		 $("#"+target).collapse("show");
		 if(dc > 2)
			document.getElementById(target).scrollIntoView({ behavior: "smooth" });
	}
	
});

</script>

</body>
</html>