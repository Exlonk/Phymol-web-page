<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 
	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.php">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <!-- start main nav -->
     <?php include("nav.php"); ?>
    <!-- end main nav -->
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		   <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
	  
			<h4 class="content-title">PARTNERS</h4>
			
			<div id="molssi" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/molssi.png"></div>
				
				<h4 class="bentitle pl170">MolSSI : The Molecular Sciences Software Institute</h4>
				<p class="pl170">The Molecular Sciences Software Institute serves as a nexus for science, education, and cooperation serving the worldwide community of computational molecular scientists – a broad field including of biomolecular simulation, quantum chemistry, and materials science. The Institute will help the computational molecular science community to work together to leverage its diverse capabilities that will reduce or eliminate the gulf that currently delays by years the practical realization of theoretical innovations.			<br/>			
				The MolSSI specializes in software training in the computational molecular sciences, and we have extensive experience in a number of topics that will be covered in this ITN in regards software schools, workshops, and mentorship of graduate student and postdoctoral trainees. The MolSSI also has experience in running a Software Fellows program whereby graduate students and postdocs are mentored in their software endeavors by our Molecular Software Scientists.
				</p>
				<p class="pl170">Website: <a href="https://molssi.org/" target="_blank">MolSSI</a></p>
			    <p class="pl170">PHYMOL member: <br/>
					<a href="https://thglab.berkeley.edu/" target="_blank" style="padding-left: 10px;">Prof. Teresa Head-Gordon</a>
					
				</p>
			</div>
			
			<div class="small-break"></div>

			<div id="auburn" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/ucl.svg"></div>
				
				<h4 class="bentitle pl170">University College London</h4>
				<p class="pl170">
				University College London (UCL) is a leading public research university located in London, United Kingdom. 
				Known for its prestigious academic offerings, UCL stands out with its strong emphasis on research across 
				a multitude of disciplines. It fosters a vibrant community where innovative and critical thinking is 
				encouraged. UCL is dedicated to providing top-tier education and has a rich tradition of excellence, 
				with a commitment to shaping future leaders and engaging with global challenges through a diverse, 
				inclusive perspective.
				<br>
				University College London's Department of Chemistry is renowned for its trailblazing research in computational 
				chemistry, among other domains. With a robust team of over fifty academic staff members, the department fosters a 
				collaborative environment where computational and experimental chemists unite to propel innovations. Their 
				research ambitiously extends computational methodologies and augments simulation efficacy to delve into molecular 
				intricacies. This integrative approach underscores the department’s commitment to advancing the frontier of 
				molecular sciences. 
				</p>
				<p class="pl170">Website: <a href="https://www.ucl.ac.uk" target="_blank">University College London</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://profiles.ucl.ac.uk/94278-rachel-crespo-otero/about" target="_blank" style="padding-left: 10px;">Prof. Rachel Crespo Otero</a>
					
				</p>
			</div>

			<div id="auburn" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/auburn.png"></div>
				
				<h4 class="bentitle pl170">Auburn University</h4>
				<p class="pl170">Auburn University is flagship public university in Alabama, US, leading university in the south, recently elevated to R1 category the Carnegie Classification of Institutions of Higher Education. The Chemistry Department has 24 full-time faculty members with expertise in biological chemistry, synthesis methodology, molecular recognition and detection, new material synthesis and characterization, renewable energy, and very strong involvement in computational chemistry. <br/>						
				Prof. Patkowski is Professor of Chemistry and Biochemistry. He is one of the best experts in accurate calculations of interaction energies of weakly bound systems, author of over 40 papers (H-index 25). His expertise includes benchmarking the systems with non-covalent interactions and accurate ab-initio calculations of interaction potentials for the systems important for studies of fundamental physics, spectroscopy and metrology. He is recip- ient of ACS OpenEye Outstanding Junior Faculty Award in Computational Chemistry (2015).

				</p>
				<p class="pl170">Website: <a href="https://www.auburn.edu/" target="_blank">Auburn University</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://www.auburn.edu/cosam/faculty/chemistry/patkowski/" target="_blank" style="padding-left: 10px;">Prof. Konrad Patkowski</a>
					
				</p>
			</div>
			
			<div id="auburn" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/uam.png"></div>
				
				<h4 class="bentitle pl170">Autonomous University of Madrid</h4>
				<p class="pl170">				
				The Autonomous University of Madrid(UAM) is renowned for its excellence in the sciences, offering a 
				robust and interdisciplinary approach to research and education. It stands out for pioneering contributions
				 in areas such as biochemistry, environmental science, and physics, fostering an environment where scientific i
				 nquiry and innovation are at the forefront. UAM's commitment to addressing global scientific challenges is 
				 evidenced by its collaborative projects and state-of-the-art research facilities, making it a pivotal 
				 institution for aspiring scientists and researchers.
				</p>
				<p class="pl170">Website: <a href="https://www.uam.es/uam/inicio" target="_blank">Autonomous University of Madrid</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://www.auburn.edu/cosam/faculty/chemistry/patkowski/" target="_blank" style="padding-left: 10px;"> </a>
					
				</p>
			</div>

			<div class="small-break"></div>
			
			<div id="hitran" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/hitran.png"></div>
				
				<h4 class="bentitle pl170">HITRAN: high-resolution transmission molecular absorption database</h4>
				<p class="pl170">HITRAN is an acronym for high-resolution transmission molecular absorption database. HITRAN is a compilation of molecular spectroscopic parameters that a variety of computer codes use to predict and simulate the transmission and emission of light in the terrestrial and planetary atmospheres. HITRAN group also maintains and develops the HITEMP database. <br/>
				Key Expertise: <br/>
				Collection and validation of spectroscopic data to be maintained in the HiTRAN database. The HITRAN group develops effective tools for dissemination of the spectroscopic data and keeps close contact with the user community. The HITRAN group has vast expertise in molecular spectroscopy, data science and applications.
				
				</p>
				<p class="pl170">Website: <a href="https://hitran.org/" target="_blank">HITRAN</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://lweb.cfa.harvard.edu/~igordon/" target="_blank" style="padding-left: 10px;">Dr. Iouli E. Gordon</a>
					
				</p>
			 
			</div>
			
			<div class="small-break"></div>
			
			<div id="nanogap" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/nanogap.png"></div>
				
				<h4 class="bentitle pl170">NANOGAP </h4>
				<p class="pl170">NANOGAP is a spin-out from the University of Santiago de Compostela. NANOGAP develops, manufactures and sells nanomaterials. The core technology is based on wet chemistry and sub-nanometer Atomic Quantum Clusters (AQCs) with unique properties. Target markets include printed electronics, security printing, medical diagnostics and catalysts.
				</p>
				<p class="pl170">Website: <a href="https://nanogap.es/" target="_blank">NANOGAP</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://investigacion.usc.gal/investigadores/59485/detalle?lang=en" target="_blank" style="padding-left: 10px;">Prof. M. Arturo López-Quintela</a>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="cesga" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/cesga.png"></div>
				
				<h4 class="bentitle pl170">Supercomputing Center of Galicia (CESGA) </h4>
				<p class="pl170">CESGA was founded in 1993 to promote and provide supercomputing to the academic and non-academic communities. It employs more than 35 people and has more than 325 TeraFlops of computing capacity with a 4 PetaFLOPS update in progress.	<br/>
				Dr. Gómez is the manager of the Projects and Applications department at CESGA and Dr. Rodríguez senior scientific application technician. They have experience in the design of distributed and HPC systems, the management, support, parallelisation, migration of applications, the application of Machine Learning techniques to industrial processes, and scientific and technical software development. A. Gómez is involved in several Quantum Computing initiatives, being nowadays a main research line at CESGA. The main scientific computing infrastructure managed by CESGA is FinisTerrae, conceived for the efficient resolution of large parallel problems. In 2021, a new supercomputer is being deployed (4PFlops) including the first Quantum Computing Simulator installed in Spain.
				</p>
				<p class="pl170">Website: <a href="https://nanogap.es/" target="_blank">CESGA</a></p>
			    <p class="pl170">PHYMOL members: <br/>
					<a href="https://www.linkedin.com/in/andr%C3%A9s-g%C3%B3mez-779161a/" target="_blank" style="padding-left: 10px;">Dr. Andrés Gómez</a><br/>
					<a href="https://www.linkedin.com/in/cesga-aurelio-rodr%C3%ADguez/" target="_blank" style="padding-left: 10px;">Dr. Aurelio Rodrígez</a>
					
				</p>
			</div>
			
			<div class="small-break"></div>
			
			<div id="soldrevet" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/soldrevet.png"></div>
				
				<h4 class="bentitle pl170">Soldrevet Chemistry by Thomas Preston </h4>
				<p class="pl170">Soldrevet provides a) bespoke chemistry research in concert with small-medium chemical engineering firms through computational chemistry modelling and material-production process design, b) career guidance through one-on-one coaching and workshops, and c) computational chemical and physical modelling research with university research groups.<br/>
				
				Dr. Thomas Preston (sole proprietor): applications of computational chemistry and chemical modelling for use in sustainable development; education and training for researchers.
				</p>
				<p class="pl170">Website: <a href="https://soldrevet.com/" target="_blank">Soldrevet</a></p>
			    <p class="pl170">PHYMOL members: <br/>
					<a href="https://soldrevet.com/about/" target="_blank" style="padding-left: 10px;">Dr. Thomas Preston</a>
					
				</p>
			</div>

			<div id="KIDO" class="boxed autodiv">
				<div class="avatar"><img alt="" src="pics/KIDO.png"></div>
				
				<h4 class="bentitle pl170">KIDO DYNAMICS SA</h4>
				<p class="pl170">Kido Dynamics is a company composed by scientists and engineers dedicated to democratize Big Data providing the most advanced solutions for Smart Cities. Kido’s team develops their own solutions in Big Data and Machine Learning built on top of the state-of-the-art technologies. Kido’s systems are deployed in the cloud, making them globally accessible. With strong background in theoretical physics, the lead scientists in Kido apply their knowledge in computation of quantum systems to solve Big Data problems in the growing complexity of human mobility and Smart Cities. These same techniques can be applied to solve a wide range of problems in computational quantum physics and chemistry.</p>
				<p class="pl170">Website: <a href="https://www.kidodynamics.com/" target="_blank">KIDO</a></p>
				<p class="pl170">PHYMOL member: <br/>
					<a href="https://www.researchgate.net/profile/Alberto-Hernando-De-Castro" target="_blank" style="padding-left: 10px;">Dr. Alberto Hernando</a><br/>
					
				</p>
			</div>
      </div>
	  
	  
	   <!--
	   Right content
	  -->
       <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 


<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 



</body>
</html>