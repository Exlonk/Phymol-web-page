<?php

include("include/classes/session.php");

function redirect($url)
{
	if (headers_sent()){
	  die('<script type="text/javascript">window.location.href="' . $url . '";</script>');
	}else{
	  header('Location: ' . $url);
	  die();
	}    
}

function truncate($string, $length, $dots = "...") {
    return (strlen($string) > $length) ? substr($string, 0, $length - strlen($dots)) . $dots : $string;
}

if ((!$session->logged_in)) {
	if(!$session->isLevel9()){
		redirect("index.php");
	}
}

mysqli_query($database->connection, "SET NAMES UTF8");
mysqli_query($database->connection, "set character set UTF8");
mysqli_query($database->connection, "set collation_connection='utf8_unicode_ci'");

$page = $_GET['page'];

// create new news
if (@$_POST["newnews"] === "Submit") {

	$title =  mysqli_real_escape_string($database->connection, $_POST['title']);
	$text  =  mysqli_real_escape_string($database->connection, $_POST['text']);
		
	$sql="INSERT INTO news (title, text)
			VALUES
	('$title','$text')";
		
	mysqli_query($database->connection, $sql) or die('Error, query failed');

	header("Location: admin.php?text=1");

} 



// edit a news
if (@$_POST["editnews"] === "Submit") {

    $id= $_POST['id'];
	$title =  mysqli_real_escape_string($database->connection, $_POST['title']);
	$text  =  mysqli_real_escape_string($database->connection, $_POST['text']);
								
		
	$upsql="UPDATE news SET title='$title', text='$text', live='1' WHERE id='$id'";
	$result = mysqli_query($database->connection, $upsql) or die('Error, query failed');
	header("Location: admin.php?text=2");
		
} 

// delete a news
if($page == 4)
{
	$id= $_GET['id'];
	$upsql="UPDATE news SET live='0' WHERE id='$id'";
	$result = mysqli_query($database->connection, $upsql) or die('Error, query failed');
	header("Location: admin.php?text=2");	
}


// create new events
if (@$_POST["newevents"] === "Submit") {

	$date =  mysqli_real_escape_string($database->connection, $_POST['date']);
	$text  =  mysqli_real_escape_string($database->connection, $_POST['text']);
		
	$sql="INSERT INTO events (date, text)
			VALUES
	('$date','$text')";
		
	mysqli_query($database->connection, $sql) or die('Error, query failed');

	header("Location: admin.php?text=1");

} 	


// edit a news
if (@$_POST["editevent"] === "Submit") {

    $id= $_POST['id'];
	$date =  mysqli_real_escape_string($database->connection, $_POST['date']);
	$text  =  mysqli_real_escape_string($database->connection, $_POST['text']);
								
		
	$upsql="UPDATE events SET date='$date', text='$text', live='1' WHERE id='$id'";
	$result = mysqli_query($database->connection, $upsql) or die('Error, query failed');
	header("Location: admin.php?text=2");
		
}

// delete a event
if($page == 8)
{
	$id= $_GET['id'];
	$upsql="UPDATE events SET live='0' WHERE id='$id'";
	$result = mysqli_query($database->connection, $upsql) or die('Error, query failed');
	header("Location: admin.php?text=2");	
}
						

?>
<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="Sugarland – Contemporary Portfolio for Creatives that Stands Out" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script> 


	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.html">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <?php include("nav.php"); ?>
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		 <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
			
			
			<!-- NEW NEWS -->
			<?php if($page == 1) { ?>
				<h4>New News</h4>
				<div class="small-break"></div>
				<form action="doit.php" method="POST" enctype="multipart/form-data"> 
					<div class="form-group">
						<label for="title">Title of the News</label>
						<input class="form-control" id="title" name="title" type="text" placeholder="">
					</div>
					
					<div class="form-group">
						<label for="text">Text of the News</label>
						<textarea class="form-control" id="text" name="text" rows="3"></textarea>
					</div>
					
					
					<input type="submit" class="btn btn-success" name="newnews" value="Submit" />
					<a href="admin.php" class="btn btn-danger pull-right" role="button">Cancel</a>
				</form>
			<?php } ?>
			
			<!-- EDIT NEWS -->
			
			<?php if($page == 2) { ?>
				<h4>Edit News</h4>
				<div class="small-break"></div>
				
				<table class="table">
				  <thead>
					<tr>
					  <th scope="col">Title</th>
					  <th scope="col">Text</th>
					  <th scope="col">Edit</th>
					  <th scope="col">Delete</th>
					</tr>
				  </thead>
				  <tbody>
				
				<?php 	
					$sql = "SELECT * FROM news where live=1";
					$result = mysqli_query($database->connection, $sql) or die('Error, query failed');
					
					while($row = $result->fetch_assoc()) {
						echo "<tr><td>".truncate($row["title"], 20)."</td><td>".truncate($row["text"],40)."</td><td><a href='doit.php?page=3&id=".$row["id"]."' class='btn btn-info btn-sm' role='button'>Edit</a></td><td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='doit.php?page=4&id=".$row['id']."' class='btn btn-danger btn-sm' role='button'>Delete</a></td></tr>";

				  }
				  ?>
	
				  </tbody>
				</table>
			<?php }
//onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?id=".$query2['id']."
			?>
			
			
			<!-- EDIT ONE NEWS -->
			
			<?php if($page == 3) { 
			
				if (isset($_GET['id'])) {
					
					$id= $_GET['id'];
					$sql = "SELECT * FROM news where id=$id";
					$result = mysqli_query($database->connection, $sql) or die('Error, query failed');
					
			
			?>
				<h4>Edit a News</h4>
				<div class="small-break"></div>
				<form action="doit.php" method="POST" enctype="multipart/form-data"> 
				
				 <?php while($row = $result->fetch_assoc()) { ?>
					<div class="form-group">
						<label for="title">Title of the News</label>
						<input class="form-control" id="title" name="title" type="text" placeholder="" value="<?php echo $row["title"]?>">
						<input class="form-control" id="id" name="id" type="text" style="display:none" value="<?php echo $row["id"]?>">
						
					</div>
					
					<div class="form-group">
						<label for="text">Text of the News</label>
						<textarea class="form-control" id="text" name="text" rows="3"><?php echo $row["text"]?></textarea>
					</div>
				 <?php } ?>	
					
					<input type="submit" class="btn btn-success" name="editnews" value="Submit" />
					<a href="admin.php" class="btn btn-danger pull-right" role="button">Cancel</a>
				</form>
				
			<?php } } ?>
			
			<!-- NEW EVENTS -->
			<?php if($page == 5) { ?>
				<h4>New Events</h4>
				 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

				<script src="https://www.jonthornton.com/jquery-timepicker/jquery.timepicker.js"></script>
				<link rel="stylesheet" type="text/css" href="https://www.jonthornton.com/jquery-timepicker/jquery.timepicker.css" />

				<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
				<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.standalone.css" />

				<script src="date/pikaday.js"></script>
				<link rel="stylesheet" type="text/css" href="date/pikaday.css" />

				<script src="date/jquery.ptTimeSelect.js"></script>
				<link rel="stylesheet" type="text/css" href="date/jquery.ptTimeSelect.css" />
				<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/ui-lightness/jquery-ui.css" type="text/css" media="all" />

				<script src="date/moment.min.js"></script>
				<script src="date/datepair.js"></script>
				<script src="date/jquery.datepair.js"></script>
				
				<div class="small-break"></div>
				<form action="doit.php" method="POST" enctype="multipart/form-data"> 
					<div class="form-group">
						<label for="title">Date of the News</label><span> (format: yyyy-mm-dd)</span>
						<input class="form-control" id="date" name="date" type="text" placeholder="">
					</div>
					
					<div class="form-group">
						<label for="text">Text of the Events</label>
						<textarea class="form-control" id="text" name="text" rows="3"></textarea>
					</div>
					
					
					<input type="submit" class="btn btn-success" name="newevents" value="Submit" />
					<a href="admin.php" class="btn btn-danger pull-right" role="button">Cancel</a>
					
					<script>


					$('#date').datepicker({
						'format': 'yyyy-m-d',
						'autoclose': true
					});

					var basicExampleEl = document.getElementById('date');
					var datepair = new Datepair(basicExampleEl);
				</script>

				</form>
			<?php } ?>
			
			
			<!-- EDIT EVENTS -->
			
			<?php if($page == 6) { ?>
				<h4>Edit Events</h4>
				<div class="small-break"></div>
				
				<table class="table">
				  <thead>
					<tr>
					  <th scope="col">Date</th>
					  <th scope="col">Text</th>
					  <th scope="col">Edit</th>
					  <th scope="col">Delete</th>
					</tr>
				  </thead>
				  <tbody>
				
				<?php 	
					$sql = "SELECT * FROM events where live=1";
					$result = mysqli_query($database->connection, $sql) or die('Error, query failed');
					
					while($row = $result->fetch_assoc()) {
						echo "<tr><td>".truncate($row["date"], 20)."</td><td>".truncate($row["text"],40)."</td><td><a href='doit.php?page=7&id=".$row["id"]."' class='btn btn-info btn-sm' role='button'>Edit</a></td><td><a onClick=\"javascript: return confirm('Please confirm deletion');\" href='doit.php?page=8&id=".$row['id']."' class='btn btn-danger btn-sm' role='button'>Delete</a></td></tr>";

				  }
				  ?>
	
				  </tbody>
				</table>
			<?php }
//onClick=\"javascript: return confirm('Please confirm deletion');\" href='delete.php?id=".$query2['id']."
			?>


			<!-- EDIT ONE EVENT -->
			
			<?php if($page == 7) { 
			
				if (isset($_GET['id'])) {
					
					$id= $_GET['id'];
					$sql = "SELECT * FROM events where id=$id";
					$result = mysqli_query($database->connection, $sql) or die('Error, query failed');
					
			
			?>
				<h4>Edit a News</h4>
				<div class="small-break"></div>
				<form action="doit.php" method="POST" enctype="multipart/form-data"> 
				
				 <?php while($row = $result->fetch_assoc()) { ?>
					<div class="form-group">
						<label for="title">Date of the Events</label><span> (format: yyyy-mm-dd)</span>
						<input class="form-control" id="title" name="date" type="text" placeholder="" value="<?php echo $row["date"]?>">
						<input class="form-control" id="id" name="id" type="text" style="display:none" value="<?php echo $row["id"]?>">
						
					</div>
					
					<div class="form-group">
						<label for="text">Text of the Events</label>
						<textarea class="form-control" id="text" name="text" rows="3"><?php echo $row["text"]?></textarea>
					</div>
				 <?php } ?>	
					
					<input type="submit" class="btn btn-success" name="editevent" value="Submit" />
					<a href="admin.php" class="btn btn-danger pull-right" role="button">Cancel</a>
				</form>
				
			<?php } } ?>
			
      </div>
	  
	  
	   <!--
	   Right content
	  -->
      <div class="col-md-3 col-sm-8 ">
        <div class="small-break"></div>
        <div class="boxed keys">
          <p><strong>Key Facts</strong></p>
         
          <ul class="clearfix keysul">
              <li> Scientific beneficiaries: 10 </li>
            <li> Partners: 6 </li>
            <li> Number of countries involved: 10 </li>
            <li> Budget: approx. €2.6M from Horizon Europe and €300K from UKRI. </li>
            <li> Number of funded doctoral candidates: 11 </li>
            <li> Coordinated by Prof Piotr Zuchowski from Universytet Mikłaja Kopernika, Torun </li>
            <li> PHYMOL is a doctoral network funded mainly under the Horizon Europe scheme, and also by the UK Research and Innovation</li>
          </ul>
        </div>
		
		<div  style="width:100%;">
		<a title="ITN - Marie Curie Actions" href="https://marie-sklodowska-curie-actions.ec.europa.eu/" target="_blank"><img style="max-width:150px;" class="cimage" src="pics/EC.png"></a>
		 
		 </div>
		  <div class="small-break"></div>
		 <div  class="homecontact" >
		   <p class="gold"><strong>Contact</strong></p>
		   <p class="gold">Coordinator:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:pzuch@fizyka.umk.pl"  class="gold">Piotr Zuchowski</a></p>
		    <p class="gold">Project Manager:</p>
		   <p class="gold"><i class="fa fa-envelope"></i><a href="mailto:a_wis@umk.pl"  class="gold">Agata Wiśniewska </a></p>
		 
		 </div>
		 <div class="small-break"></div>
		 <div  style="width:100%; padding-left:10px">
		   <p class="gold">Also find us on :</p>
		   
		   <ul class="social-list clearfix">
			
			<li> <a href="https://www.linkedin.com/company/85627029/admin/" target="_blank" class="circled"><i class="fa fa-linkedin"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
			<li> <a href="#" class="circled"><i class="fa fa-twitter"></i>
			  <div class="circle-anim"></div>
			  </a> </li>
		  </ul>
	  
		 </div>
		 
      </div>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 


<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script> 
<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 

<script type="text/javascript" src="js/nicEdit.js"></script>
  
<script type="text/javascript">

$( document ).ready(function() {
   new nicEditor().panelInstance('text');
});

	 
</script>

</body>
</html>