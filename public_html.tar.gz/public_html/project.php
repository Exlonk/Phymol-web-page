<?php
include("include/classes/session.php");

?>

<!DOCTYPE html>
<html class="no-js ajax-content" lang="en">
<head>
<meta charset="utf-8">
<title>PHYMOL</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="author" content="Tibor Furtenbacher">
<meta name="Description" content="PHYMOL" />
<link href="css/reset.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="css/contact.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/custom.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css" media="screen" />
<script src="js/modernizr.js" type="text/javascript"></script>
<script src="js/jquery-1.12.4.min.js" type="text/javascript"></script> 

<style type="text/css">
        #mynetwork {
            width: 750px;
            height: 600px;
            border: 1px solid lightgray;
        }
		
		#mbody {
		  text-align: justify;
		}
		
	

    </style>
	
</head>
<body >
<!-- start wrapper -->
<div class="wrapper">
  <h1 id="logo"><a href="index.php">
    <div ><img src="images/logo.png" style="max-height:140px;"/></div>
    </a></h1>
  <div id="menu-button">
    <div class="cursor"> 
      <!--Menu-->
      <div id="nav-button"> <span class="nav-bar"></span> <span class="nav-bar"></span> <span class="nav-bar"></span> </div>
    </div>
  </div>
  <header> 
    
    <!-- start main nav -->
     <?php include("nav.php"); ?>
    <!-- end main nav -->
   
  </header>
 
 
  <!-- start content -->
  <div id="content">
   
	 <div class="specialBackground">
		
		 <h4 ><strong>PHYMOL</strong></h4>
		  <p><strong>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</strong></p>
		
	  </div>
	 
    <div class="padding-0 clearfix">
      
    
      <div class="col-md-8 pd50">
	  
			<h4 class="content-title"> PHYMOL: Scientific goals </h4>
			
			<p style="text-align:justify;">  The fundamental interactions between (neutral) molecules are relatively weak, but they determine much of the complex phenomena in solids, liquids, and gases. These intermolecular interactions are of paramount importance at interfaces, in molecular crystals, in cells, and even in interstellar gas clouds. These interactions are not easy to compute from first principles because the small size of these energies places extreme demands on the theoretical and numerical methods used. They are also often quite difficult to model (i.e. to construct an analytic, easily computable representation) accurately due to the subtle effects of anisotropy (atoms in a molecule are not spheres), many-body non-additivity (the whole is not the sum of its parts), and quantum tunneling (charge-transfer or delocalization). Simple models ignore, or average out many of these subtleties, but while these computationally simple models allow the study of large systems at long time-scales, they do so at the cost of accuracy and predictive power. 

			<br/><br/>

			This is best exemplified in blind tests of organic molecular crystal structure prediction conducted by the Cambridge Crystallographic Data Centre, which have conclusively demonstrated that the most reliable predictions of the structures and free energy ranking of the molecular crystals is obtained by a combination of advanced theory-based models with ab initio methods such as density functional theory, and these combined approaches vastly outperformed the empirical models. There are tangible consequences for the increase in predictive power that arises from paying attention to physical details of the phenomena we aim to model: in the case of molecular crystals this leads to a better understanding of the stability of the crystalline material and its polymorphs. A profound understanding is the key to avoid the humanitarian and financial disasters that have arisen when one drug form transforms into another in an unexpected way, as it has happened with the antiretroviral medication Ritonavir.

			<br/><br/>
			
			Another application is transit transmission spectroscopy, where one observes absorption by an exoplanetary atmosphere as the planet transits between us and its sun. Here, collision-induced absorption (one of the highly sensitive ways in which we will assess reference data in PHYMOL) gives information on the atmospheric pressure. Of particular interest is the measurement of collision-induced absorption by O2, as evidence of an O2-rich atmosphere could be explained by photosynthesis, and therefore life, on the exoplanet.
			<br/><br/>
			Central to these applications is the PES — the potential energy surface — that needs to be constructed as an accurate mathematical model that is capable of accurately describing the intermolecular interactions as well as those within the molecular complexes, and also the couplings between these. Additionally, the PES must be computationally cheap to evaluate so as to allow us to simulate large systems for long time-scales. This is where we see the strong interlinking of physical models and machine learning: by combining the best of these two — in a sense, by combining human learning with machine learning — we will see the biggest advances in intermolecular model building for targeted applications. 
			<br/><br/>
			
			The main scientific goals of the PHYMOL network are contained in three scientific work packages:
			<br/><br/>
			WP1 concerns the development and assessment of the fundamental theoretical models for intermolecular interactions, and serves as a means of providing skills to create and implement new ab initio models, as well as to critically evaluate the models using spectroscopic data. WP1 involves three doctoral positions: <a href="research.php?dc=1">DC1</a> will be involved with developing a new model for the induction energy, <a href="research.php?dc=2">DC2</a> will study the CO-CO* excimer, and <a href="research.php?dc=3">DC3</a> will study collision-induced absorption spectra of a number of complexes of importance to atmospheric models.
			<br/><br/>
			WP2 is focused on taking data from the best available methods currently available and, with machine-learning and the best physical understanding we possess, creating models that can be used in simulations. WP1 involves four doctoral positions:<a href="research.php?dc=4">DC4</a> will work on reparameterization of semiempirical models, <a href="research.php?dc=5">DC5</a> will develop models that incorporate the MBD dispersion model, <a href="research.php?dc=6">DC6</a> will develop methods to treat polarization and charge-delocalization on a physically equivalent footing, and <a href="research.php?dc=11">DC11</a> will develop techniques to map force-field parameters onto properties of the electronic density.

			<br/><br/>
			In WP3 we see the applications of the best available models to difficult problems faced by industry. Here, our DCs will be faced with the challenges of understanding the complex nature of real-world problems, and the issues involved with the methods and models when using them in computer simulations.  <a href="research.php?dc=7">DC7</a> will investigate how intermolecular interactions shape the energy landscape of molecular crystals, <a href="research.php?dc=8">DC8</a> will be involved with state-of-the-art modelling of metal atomic quantum clusters, <a href="research.php?dc=9">DC9</a> will develop implicit machine learning solvent models for molecules in confined spaces, and <a href="research.php?dc=10">DC10</a> will develop  open source big data analysis tools for industry. 

			<br/><br/>
			
			
			</p>
			<div class="small-break"></div>
			<div class="nocellphone">
				<h4 class="content-title">STRUCTURE of PHYMOL</h4>
				<p> For more information, click on the figure.</p>
				<div id="mynetwork"></div>
			</div>
			
			
			
			
			


        
      </div>
	  
	  
	  <!--
	   Right content
	  -->
              <?php include "right.php"; ?>
	  <!--
	   End of Right content
	  -->
	  
	  
   
   </div>
   
   <!-- Modal -->

   
    
    <footer>
      <div class="container clearfix no-header">
        <div class="col-lg-12 centered">
          
          <div class="medium-break"></div>
          <p>PHYMOL© 2023, All rights reserved</p>
          
        </div>
      </div>
    </footer>
  </div>
  <!-- end content --> 
  
  

</div>
<!-- end wrapper --> 

<script src="js/jquery-easing-1.3.js" type="text/javascript"></script> 
<script src="js/jquery.touchSwipe.min.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/main.js" type="text/javascript"></script> 
<script src="js/jquery.fancybox.pack.js" type="text/javascript"></script> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<script src="js/jquery.sliphover.min.js" type="text/javascript"></script>
<script src="js/vis.js"></script>

<script>

const desc = new Map();

$(document).ready(function() {

	const desc = new Map();
	
	
	desc.set(1, "<b>Physics, Accuracy and Machine Learning: Towards the next-generation of Molecular Potentials</b> <br/>In the PHYMOL collaboration we bring together leading experts in the fields of molecular simulations, quantum chemistry, crystal structure prediction, intermolecular modelling, spectroscopy, machine-learning, and nano-clusters, from 12 academic institutes and national laboratories, and 4 industrial entities, in an ambitious programme of research and training to develop a new generation of researchers in the field of molecular modelling. PHYMOL combines the most advanced physical understanding of molecular interactions with machine-learning in a symbiotic manner that will lead to a new generation of researches capable of advancing solutions to problems of importance in healthcare, energy and the environment, as well as basic science. The private sector is an integral part of PHYMOL and participates in management, training and research. With this union of forces from academia, industry from the EU and the US, we seek to keep molecular simulation techniques at the fore-front of industry and science in the EU.");
	
	desc.set(2, "<b>Objectives</b>: To ensure the smooth operation of the network.");
	desc.set(3, "<b>Objectives</b>: To enhance employability of DCs and convey the outcome of the network to the society.");
	desc.set(4, "<b>Objectives</b>: To deliver a high standard of scientific and soft-skills training to all DCs.");
	desc.set(5, "<b>Objectives</b>: Soldrevet Chemistry <br/> <b>Homepage</b>: <a href='https://soldrevet.com/' target='_blank'>https://soldrevet.com/</a> ");
	desc.set(6, "<b>Objectives</b>: Applications of the models to systems relevant to industry.");
	desc.set(7, "<b>Objectives</b>: NANOGAP<br/> <b>Homepage</b>: <a href='https://nanogap.es/' target='_blank'>https://nanogap.es</a> ");
	desc.set(8, "<b>Objectives</b>: KIDO Dynamics SA<br/> <b>Homepage</b>: <a href='https://www.kidodynamics.com/' target='_blank'>https://www.kidodynamics.com/</a> ");
	desc.set(20, "<b>Objectives</b>: KIDO Dynamics SA<br/> <b>Homepage</b>: <a href='https://www.kidodynamics.com/' target='_blank'>https://www.kidodynamics.com/</a> ");
	desc.set(13, "<b>Objectives</b>: Sorbonne Université<br/> <b>Homepage</b>: <a href='https://www.sorbonne-universite.fr/' target='_blank'>https://www.sorbonne-universite.fr/</a> ");
	desc.set(19, "<b>Objectives</b>: Sorbonne Université<br/> <b>Homepage</b>: <a href='https://www.sorbonne-universite.fr/' target='_blank'>https://www.sorbonne-universite.fr/</a> ");
	desc.set(11, "<b>Objectives</b>: Université du Luxembourg<br/> <b>Homepage</b>: <a href='https://wwwen.uni.lu/' target='_blank'>https://wwwen.uni.lu/</a> ");
	desc.set(18, "<b>Objectives</b>: Université du Luxembourg<br/> <b>Homepage</b>: <a href='https://wwwen.uni.lu/' target='_blank'>https://wwwen.uni.lu/</a> ");
	desc.set(9, "<b>Objectives</b>: Avant-garde Materials Simulations<br/> <b>Homepage</b>: <a href='https://www.avmatsim.eu/' target='_blank'>https://www.avmatsim.eu/</a> ");
	desc.set(17, "<b>Objectives</b>: Avant-garde Materials Simulations<br/> <b>Homepage</b>: <a href='https://www.avmatsim.eu/' target='_blank'>https://www.avmatsim.eu/</a> ");
	desc.set(10, "<b>Objectives</b>: Consejo Superior de Investigaciones Cientificas<br/> <b>Homepage</b>: <a href='https://www.csic.es/en' target='_blank'>https://www.csic.es/en</a> ");
	desc.set(16, "<b>Objectives</b>: Consejo Superior de Investigaciones Cientificas<br/> <b>Homepage</b>: <a href='https://www.csic.es/en' target='_blank'>https://www.csic.es/en</a> ");
	
    desc.set(23, "<b>Objectives</b>: Develop SAPT and SAPT(DFT) methods for intermolecular interactions of electronically excited states, compute excimer spectra to test themethods against wave function method results and experiment. Compute collision induced absorption spectra.");
    desc.set(14, "<b>Objectives</b>: Development of systematic ab initio procedures to coarse grain complex quantum-mechanical phenomena into effective interactions. The derived force fields enable the study of large systems in the condensed phase. The use of machine learning enhances transferability across chemistry.");
    desc.set(27, "<b>Objectives</b>: High-resolution transmission molecular absorption database.<br/> <b>Homepage</b>: <a href='https://hitran.org' target='_blank'>https://hitran.org/</a> ");
    desc.set(15, "<b>Objectives</b>: The Molecular Sciences Software Institute<br/> <b>Homepage</b>: <a href='https://molssi.org/' target='_blank'>https://molssi.org</a> ");
    desc.set(25, "<b>Objectives</b>: The Molecular Sciences Software Institute<br/> <b>Homepage</b>: <a href='https://molssi.org/' target='_blank'>https://molssi.org</a> ");
    desc.set(22, "<b>Objectives</b>: Fundación Pública Galega Centro Tecnolóxico de Supercomputación de Galicia<br/> <b>Homepage</b>: <a href='https://www.cesga.es/cesga/' target='_blank'>https://www.cesga.es/cesga/</a> ");
    desc.set(24, "<b>Objectives</b>: Fundación Pública Galega Centro Tecnolóxico de Supercomputación de Galicia<br/> <b>Homepage</b>: <a href='https://www.cesga.es/cesga/' target='_blank'>https://www.cesga.es/cesga/</a> ");
    desc.set(26, "<b>Objectives</b>: Auburn University<br/> <b>Homepage</b>: <a href='https://www.auburn.edu/' target='_blank'>https://www.auburn.edu/</a> ");
    desc.set(12, "<b>Objectives</b>: Queen Mary University of London<br/> <b>Homepage</b>: <a href='https://www.qmul.ac.uk/' target='_blank'>https://www.qmul.ac.uk/</a> ");
    desc.set(21, "<b>Objectives</b>: Queen Mary University of London<br/> <b>Homepage</b>: <a href='https://www.qmul.ac.uk/' target='_blank'>https://www.qmul.ac.uk/</a> ");
    desc.set(28, "<b>Objectives</b>: Queen Mary University of London<br/> <b>Homepage</b>: <a href='https://www.qmul.ac.uk/' target='_blank'>https://www.qmul.ac.uk/</a> ");
    desc.set(29, "<b>Objectives</b>: Universidad de Santiago de Compostela<br/> <b>Homepage</b>: <a href='https://www.usc.gal/gl' target='_blank'>https://www.usc.gal/gl</a> ");
    desc.set(30, "<b>Objectives</b>: Eötvös Loránd University<br/> <b>Homepage</b>: <a href='https://www.elte.hu/' target='_blank'>https://www.elte.hu/</a> ");
    desc.set(31, "<b>Objectives</b>: Radboud University Nijmegen<br/> <b>Homepage</b>: <a href='https://www.ru.nl/en' target='_blank'>https://www.ru.nl/en</a> ");
    desc.set(32, "<b>Objectives</b>: Universytet Mikłaja Kopernika, Torun<br/> <b>Homepage</b>: <a href='https://www.umk.pl/' target='_blank'>https://www.umk.pl/</a> ");
	

    // create an array with nodes
    var nodes = new vis.DataSet([
        {id: 1, color: 'black', label: '    PHYMOL     ', margin: 20,  font: {color:'white'}, size: 60,  shape: 'circle', x: 0, y: 0  },
        {id: 2, color: 'purple', font: { multi: true, color: 'white' }, label: '<b>WP6</b> \n<i>Management</i> ',  size: 40,  shape: 'circle', x: 10, y: -150  },
        {id: 3, color: 'darkcyan', font:{ multi: true, color: 'white' }, margin: 20, label: '<b>WP5</b> \n<i>Impact</i> ', size: 40,  shape: 'circle', x: -100, y: -100  },
        {id: 4, color: 'orange', font:{ multi: true, color: 'white' }, margin: 20, label: '<b>WP4</b> \n<i>Training</i> ', size: 40,  shape: 'circle', x: -150, y: 0  },
        {id: 5, color: 'orange', font:{ multi: true, color: 'black' }, label: '<b>Soldrevet</b> ', size: 40,  shape: 'circle', x: -250, y: 0  },
		{id: 6, color: 'red', font:{ multi: true, color: 'white' }, label: '<b>WP3</b> \n<i>Applications</i>\n<i>to real</i>\n<i>systems</i> ', size: 40,  shape: 'circle', x: -150, y: 150  },
		{id: 7, color: 'orange', font:{ multi: true, color: 'black' }, label: '<b>NANO</b>\n<b>-GAP</b>', size: 40,  shape: 'circle', x: -230, y: 100  },
		{id: 8, color: 'red', font:{ multi: true, color: 'white' }, label: '<b>KIDO</b>', size: 40,  shape: 'circle', x: -250, y: 150  },
		{id: 9, color: 'red', font:{ multi: true, color: 'white' }, label: '<b>AMS</b>', size: 40,  shape: 'circle', x: -230, y: 200  },
		{id: 10, color: 'red', font:{ multi: true, color: 'white' }, label: '<b>CSIC</b>', size: 40,  shape: 'circle', x: -180, y: 220  },
		{id: 11, color: 'red', font:{ multi: true, color: 'white' }, margin: 7, label: '<b> UL </b>', size: 40,  shape: 'circle', x: -130, y: 225  },
		{id: 12, color: 'red', font:{ multi: true, color: 'white' },  label: '<b> QMUL </b>', size: 40,  shape: 'circle', x: -80, y: 200  },
		{id: 13, color: 'red', font:{ multi: true, color: 'white' }, margin: 7,  label: '<b> SU </b>', size: 40,  shape: 'circle', x: -80, y: 140  },
		{id: 14, color: 'blue', font:{ multi: true, color: 'white' }, margin: 12,   label: '<b> WP2 </b>\nForce-\nFields, \nModels and \nMachine- \nLearning', size: 40,  shape: 'circle', x: 90, y: 160  },
		{id: 15, color: 'orange', font:{ multi: true, color: 'black' },  label: '<b>MolSSI</b>', size: 40,  shape: 'circle', x: 10, y: 110  },
		{id: 16, color: 'blue', font:{ multi: true, color: 'white' },  label: '<b>CSIC</b>', size: 40,  shape: 'circle', x: 0, y: 170  },
		{id: 17, color: 'blue', font:{ multi: true, color: 'white' },  label: '<b>AMS</b>', size: 40,  shape: 'circle', x: 20, y: 220  },
		{id: 18, color: 'blue', font:{ multi: true, color: 'white' }, margin: 7,  label: '<b> UL </b>', size: 40,  shape: 'circle', x: 60, y: 240  },
		{id: 19, color: 'blue', font:{ multi: true, color: 'white' }, margin: 7,  label: '<b> SU </b>', size: 40,  shape: 'circle', x: 110, y: 240  },
		{id: 20, color: 'blue', font:{ multi: true, color: 'white' },  label: '<b>KIDO</b>', size: 40,  shape: 'circle', x: 160, y: 210  },
		{id: 21, color: 'blue', font:{ multi: true, color: 'white' },  label: '<b>QMUL</b>', size: 40,  shape: 'circle', x: 175, y: 150  },
		{id: 22, color: 'orange', font:{ multi: true, color: 'black' },  label: '<b>CESGA</b>', size: 40,  shape: 'circle', x: 145, y: 90  },
		{id: 23, color: 'green', font:{ multi: true, color: 'white' }, margin: 14,   label: '<b> WP1 </b>\nMethod\ndevelopment, \nReference and \nData & \nSpectroscopy', size: 40,  shape: 'circle', x: 170, y: -50  },
		{id: 24, color: 'orange', font:{ multi: true, color: 'black' },  label: '<b>CESGA</b>', size: 40,  shape: 'circle', x: 110, y: -130  },
		{id: 25, color: 'orange', font:{ multi: true, color: 'black' },  label: '<b>MolSSI</b>', size: 40,  shape: 'circle', x: 170, y: -150  },
		{id: 26, color: 'orange', font:{ multi: true, color: 'black' }, margin: 2,  label: '<b>AuburnU</b>', size: 40,  shape: 'circle', x: 230, y: -130  },
		{id: 27, color: 'orange', font:{ multi: true, color: 'black' }, margin: 2,  label: '<b>HITRAN</b>', size: 40,  shape: 'circle', x: 270, y: -80  },
		{id: 28, color: 'green', font:{ multi: true, color: 'white' },  label: '<b>QMUL</b>', size: 40,  shape: 'circle', x: 260, y: -20  },
		{id: 29, color: 'green', font:{ multi: true, color: 'white' },  label: '<b>USC</b>', size: 40,  shape: 'circle', x: 230, y: 20  },
		{id: 30, color: 'green', font:{ multi: true, color: 'white' },  label: '<b>ELTE</b>', size: 40,  shape: 'circle', x: 180, y: 40  },
		{id: 31, color: 'green', font:{ multi: true, color: 'white' },  label: '<b>RUN</b>', size: 40,  shape: 'circle', x: 135, y: 30  },
		{id: 32, color: 'green', font:{ multi: true, color: 'white' },  label: '<b>UMK</b>', size: 40,  shape: 'circle', x: 95, y: 5  },
		
      
    ]);

    // create an array with edges
    var edges = new vis.DataSet([
        {from: 1, to: 2, color:{color:'purple'}, width: 6},
        {from: 1, to: 3, color:{color:'darkcyan'}, width: 6},
        {from: 1, to: 4, color:{color:'orange'}, width: 6},
        {from: 4, to: 5, color:{color:'orange'}, width: 6},
        {from: 1, to: 6, color:{color:'red'}, width: 6},
        {from: 6, to: 7, color:{color:'orange'}, width: 6},
        {from: 6, to: 8, color:{color:'red'}, width: 6},
        {from: 6, to: 9, color:{color:'red'}, width: 6},
        {from: 6, to: 10, color:{color:'red'}, width: 6},
        {from: 6, to: 11, color:{color:'red'}, width: 6},
        {from: 6, to: 12, color:{color:'red'}, width: 6},
        {from: 6, to: 13, color:{color:'red'}, width: 6},
        {from: 1, to: 14, color:{color:'blue'}, width: 6},
        {from: 14, to: 15, color:{color:'orange'}, width: 6},
        {from: 14, to: 16, color:{color:'blue'}, width: 6},
        {from: 14, to: 17, color:{color:'blue'}, width: 6},
        {from: 14, to: 18, color:{color:'blue'}, width: 6},
        {from: 14, to: 19, color:{color:'blue'}, width: 6},
        {from: 14, to: 20, color:{color:'blue'}, width: 6},
        {from: 14, to: 21, color:{color:'blue'}, width: 6},
        {from: 14, to: 22, color:{color:'orange'}, width: 6},
        {from: 1, to: 23, color:{color:'green'}, width: 6},
		{from: 23, to: 24, color:{color:'orange'}, width: 6},
		{from: 23, to: 25, color:{color:'orange'}, width: 6},
		{from: 23, to: 26, color:{color:'orange'}, width: 6},
		{from: 23, to: 27, color:{color:'orange'}, width: 6},
		{from: 23, to: 28, color:{color:'green'}, width: 6},
		{from: 23, to: 29, color:{color:'green'}, width: 6},
		{from: 23, to: 30, color:{color:'green'}, width: 6},
		{from: 23, to: 31, color:{color:'green'}, width: 6},
		{from: 23, to: 32, color:{color:'green'}, width: 6},
       /* {from: 1, to: 2},
        {from: 2, to: 4},
        {from: 2, to: 5}*/
    ]);

    // create a network
    var container = document.getElementById('mynetwork');
    var data = {
        nodes: nodes,
        edges: edges
    };

    var options = {
		physics: false,
		interaction: {
			dragNodes: false,// do not allow dragging nodes
			zoomView: false, // do not allow zooming
			dragView: false  // do not allow dragging
		}
		
	};

    var network = new vis.Network(container, data, options);

    network.on("click", function (params) {
      
		var index = parseInt(this.getNodeAt(params.pointer.DOM));
		
		var dd = "";
		
		if(desc.has(index))
		{
			dd = desc.get(index);
		} else {
		   dd="<b>Description</b>: <br/> <b>Homepage</b>: URL "
		}
		
		$("#mtitle").html(nodes.get(index).label);
		$("#mbody").html(dd);
		
		$('#exampleModal').modal('show'); 
	});

});

</script>

<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<h5 class="modal-title" id="mtitle"></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body" id="mbody">
				   
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					
				  </div>
				</div>
			  </div>
			</div>
			<!-- Modal End -->

</body>
</html>